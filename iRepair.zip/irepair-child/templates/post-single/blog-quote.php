<?php
	global $post;
	// get meta options/values
	$irepair_content = get_post_meta($post->ID, 'pix_post_quote_content', 1);
	$irepair_source = get_post_meta($post->ID, 'pix_post_quote_source', 1) == '' ? '' : '<div class="blog-quote-source">'.wp_kses_post(get_post_meta($post->ID, 'pix_post_quote_source', 1)).'</div>';

	if($irepair_content != '') :
?>

	<blockquote>
        <?php echo wp_kses_post($irepair_content); ?>
        <?php echo wp_kses_post($irepair_source)?>
    </blockquote>
	
<?php endif; ?>

