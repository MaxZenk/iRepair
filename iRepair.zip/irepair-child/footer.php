<?php

	$post_ID = isset ($wp_query) ? $wp_query->get_queried_object_id() : (get_the_ID()>0 ? get_the_ID() : '');

    if( class_exists( 'WooCommerce' ) && irepair_is_woo_page() && irepair_get_option('woo_header_global','1') ){
		$post_ID = get_option( 'woocommerce_shop_page_id' ) ? get_option( 'woocommerce_shop_page_id' ) : $post_ID;
	} elseif (!is_page_template('page-home.php') && get_option('page_for_posts') != ''){
		$post_ID = get_option('page_for_posts') ? get_option('page_for_posts') : 0;
	}

	$irepair_header = apply_filters('irepair_header_settings', $post_ID);

	$logo = irepair_get_option('general_settings_logo');
	$logo_text = irepair_get_option('general_settings_logo_text');

	$topFooterBlockId = false;
	$bottomFooterBlockId = false;

	$topFooterBlockId = in_array(get_post_meta($post_ID, 'pix_page_top_footer_staticblock', true), array('global', '')) || $post_ID == '' ? irepair_get_option('footer_block_top') : get_post_meta($post_ID, 'pix_page_top_footer_staticblock', true);
	$bottomFooterBlockId = in_array(get_post_meta($post_ID, 'pix_page_footer_staticblock', true), array('global', '')) || $post_ID == '' ? irepair_get_option('footer_block') : get_post_meta($post_ID, 'pix_page_footer_staticblock', true);

	if(function_exists('icl_object_id')) {
		$topFooterBlockId = icl_object_id ($topFooterBlockId,'staticblocks',true);
		$bottomFooterBlockId = icl_object_id ($bottomFooterBlockId,'staticblocks',true);
	}

?>

<?php if ( ($topFooterBlockId != 'nofooter' || $bottomFooterBlockId != 'nofooter') && get_post_type() != 'staticblocks' ) : ?>

    <!-- Footer section -->
    <footer class="pix-footer">
   		
		<!-- Google Map -->
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2374.982811569965!2d27.21858871611358!3d53.46876728000484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46d90b45999d93cb%3A0xb89be4f5ae9ca60c!2zTWF4Rml4LmJ5LCDQodC10YDQstC40YHQvdGL0Lkg0YbQtdC90YLRgA!5e0!3m2!1sru!2sby!4v1621688872933!5m2!1sru!2sby" width="100%" height="500" style="border:0;" frameborder="0" allowfullscreen="" loading="lazy"></iframe>
		<!-- /Google Map -->

		<div class="container">
            <?php if ( $topFooterBlockId && $topFooterBlockId !='nofooter' )  { irepair_get_staticblock_content($topFooterBlockId); } ?>
            <?php if ( $bottomFooterBlockId && $bottomFooterBlockId !='nofooter' ) { irepair_get_staticblock_content($bottomFooterBlockId); } ?>

            <?php if ( !$topFooterBlockId && !$bottomFooterBlockId ):?>
                <div class="pix-footer__bottom">
                <?php if(irepair_get_option('footer_copyright', '')) : ?>
                    <div class="footer-copyright"><?php echo wp_kses_post(irepair_get_option('footer_copyright'))?></div>
                <?php endif; ?>
                    <div class="footer-copyright"><?php esc_html_e('&copy; 2020—', 'irepair')?><?php echo date('Y'); ?><?php esc_html_e(', MaxFix.by. Все права защищены.', 'irepair')?></div>
                    <!-- <div class="footer-created_by"><a target="_blank" href="<?php echo esc_url('https://true-emotions.studio')?>"><span><?php esc_html_e('PixTheme', 'irepair')?></span><?php esc_html_e(' Studio', 'irepair')?></a></div> -->
                </div>
            <?php endif; ?>

        </div>
    </footer>

<?php endif; ?>


</div>

<?php
    wp_footer();
?>
</body></html>
