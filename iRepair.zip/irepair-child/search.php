<?php
/*** The template for displaying search results pages. ***/

$irepair_custom =  get_post_custom(get_the_ID());
$irepair_layout = isset( $irepair_custom['pix_page_layout'] ) ? $irepair_custom['pix_page_layout'][0] : '2';
$irepair_sidebar = isset( $irepair_custom['pix_selected_sidebar'][0] ) ? $irepair_custom['pix_selected_sidebar'][0] : 'sidebar-1';


$blog_class = irepair_get_option('blog_settings_type', 'classic') == 'grid' ? 'row blog-masonry' : 'blog-list';
?>

<?php get_header();?>
    <section class="blog" id="pageContent">
        <div class="container">
            <div class="row">

                <?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>

				<div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-8 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?><?php endif; ?> col-sm-12 col-xs-12">

                <?php if ( have_posts() ) : ?>

                    <section class="<?php echo esc_attr($blog_class) ?>">

                    <?php get_template_part( 'loop', 'search' );?>
                        
                    </section>

                    <?php
                        the_posts_pagination( array(
                            'prev_text'          => wp_kses_post(__( '<i class="fa fa-chevron-left"></i>', 'irepair' )),
                            'next_text'          => wp_kses_post(__( '<i class="fa fa-chevron-right"></i>', 'irepair' )),
                            'screen_reader_text' => esc_html__( '&nbsp;', 'irepair'),
                        ) );
                    ?>

			    <?php else : ?>
			        <div id="post-0" class="blog-article post no-results not-found">
			            <h2><?php esc_html_e( 'Ничего не найдено', 'irepair' ); ?></h2>
			            <div class="entry-content">
			                <p><?php esc_html_e( 'Извините, но ничего не соответствует вашим критериям поиска. Пожалуйста, попытайтесь снова с другими ключевыми словами.', 'irepair' ); ?></p>
			             </div><!-- .entry-content -->
			        </div><!-- #post-0 -->
			    <?php endif; ?>

                </div>

                <?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>

            </div>
        </div>
    </section>
<?php get_footer(); ?>
			
            
            
