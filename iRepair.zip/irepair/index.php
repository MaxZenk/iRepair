<?php
/**
 * The main template file
 */

$irepair_class = array('', 'pix-no-sidebar', 'pix-right-sidebar', 'pix-left-sidebar');
$irepair_postpage_id = get_option( 'page_for_posts' );
$irepair_frontpage_id = get_option( 'page_on_front' );
$irepair_page_id = isset($wp_query) ? $wp_query->get_queried_object_id() : '';

if ( $irepair_page_id == $irepair_postpage_id && $irepair_postpage_id != $irepair_frontpage_id ) :
	$irepair_custom = isset( $wp_query ) ? get_post_custom( $wp_query->get_queried_object_id() ) : '';
	$irepair_layout = isset( $irepair_custom['pix_page_layout'] ) ? $irepair_custom['pix_page_layout'][0] : '2';
	$irepair_sidebar = isset( $irepair_custom['pix_selected_sidebar'][0] ) ? $irepair_custom['pix_selected_sidebar'][0] : 'sidebar-1';
else :
	$irepair_layout = irepair_get_option('blog_settings_sidebar_type', '2');
	$irepair_sidebar = irepair_get_option('blog_settings_sidebar_content', 'sidebar-1');
endif;

if ( ! is_active_sidebar($irepair_sidebar) ) {
    $irepair_layout = '1';
}

$blog_class = irepair_get_option('blog_settings_type', 'classic') == 'grid' ? 'row blog-masonry' : 'blog-list';

?>
<?php get_header();?>

<section class="blog">
	<div class="container">
		<div class="row sidebar-type-<?php echo esc_attr($irepair_layout); ?>">
			<?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>

			<div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-12<?php endif; ?> col-sm-12 col-xs-12 <?php echo esc_attr($irepair_class[$irepair_layout])?>">
                <section class="<?php echo esc_attr($blog_class) ?>">
                <?php
                    $wp_query = new WP_Query();
                    $pp = get_option('posts_per_page');
                    $wp_query->query('posts_per_page='.$pp.'&paged='.$paged);
                    get_template_part( 'loop', 'index' );
                ?>
                </section>
                <?php
                    the_posts_pagination( array(
                        'prev_text'          => wp_kses_post(__( '<i class="fa fa-chevron-left"></i>', 'irepair' )),
                        'next_text'          => wp_kses_post(__( '<i class="fa fa-chevron-right"></i>', 'irepair' )),
                        'screen_reader_text' => esc_html__( '&nbsp;', 'irepair'),
                    ) );
                ?>
			</div>
			<!-- end col -->

			<?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>
		</div>
		<!-- end row -->
	</div>
</section>
<?php get_footer(); ?>