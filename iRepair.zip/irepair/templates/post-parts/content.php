<?php
/**
 * This template is for displaying part of blog.
 *
 * @package Pix-Theme
 * @since 1.0
 */
$irepair_cat = '';
if( irepair_get_option('blog_settings_category', 1) ){
    $irepair_categories = get_the_category(get_the_ID());
    if($irepair_categories){
        foreach($irepair_categories as $category) {
            $irepair_cat .= '<a href="'.esc_url(get_category_link( $category->term_id )).'">'.wp_kses_post($category->cat_name).'</a>, ';
        }
        $irepair_cat = substr($irepair_cat, 0, -2);
    }
}
    if(irepair_get_option('blog_settings_type', 'classic') == 'grid') :
?>
    <h2><a href="<?php esc_url(the_permalink()) ?>"><?php wp_kses_post(the_title()) ?></a></h2>
    <?php the_excerpt(); ?>
    <div class="article-info">
        <div class="left">
            <?php if (irepair_get_option('blog_settings_date', 1)) : ?>
                <span class="article-info__date"><a href="<?php echo esc_url(get_the_permalink()) ?>"><?php echo wp_kses_post(get_the_date()) ?></a></span>
            <?php endif ?>
        </div>
        <div class="right">
            <?php if (irepair_get_option('blog_settings_category', 1) && !empty($irepair_cat)) : ?>
                <span class="article-info__categories"> <?php echo wp_kses_post($irepair_cat) ?> </span>
            <?php endif ?>
        </div>
    </div>
<?php
    else :
?>
    <div class="article-head">
		<?php if ( irepair_get_option( 'blog_settings_date', 'on' ) == 'on' ) : ?>
            <a href="<?php esc_url( the_permalink() ); ?>" class="post__date">
            <?php
            if(get_option( 'date_format') == 'j M'){
                echo sprintf( '<span>%s</span><span>%s</span>', esc_attr( get_the_date('j') ), esc_attr( get_the_date('M') ) );
            } elseif(get_option( 'date_format') == 'j F'){
                echo sprintf( '<span>%s</span><span>%s</span>', esc_attr( get_the_date('j') ), esc_attr( get_the_date('F') ) );
            } else {
                echo sprintf( '<span>%s</span>', esc_attr( get_the_date() ) );
            }
            ?>
            </a>
		<?php endif; ?>
		<h2><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h2>
		<div class="post__meta">
			<?php if ( irepair_get_option( 'blog_settings_author', 'on' ) == 'on' ) : ?>
				<span class="author"><i class="icon-user"></i><?php the_author_posts_link(); ?></span>
			<?php endif; ?>
            <?php if (irepair_get_option('blog_settings_category', 1) && !empty($irepair_cat)) : ?>
                <span class="article-info__categories post__categories"><i class="icon-folder-alt"></i><?php echo wp_kses_post($irepair_cat) ?> </span>
            <?php endif ?>
			<?php if ( comments_open() ) : ?>
			<span><i class="icon-bubbles"></i><?php comments_popup_link( esc_html__( 'Post a Comment', 'irepair' ), esc_html__( '1 comment', 'irepair' ), esc_html__( '% comments', 'irepair' ), "comments-link"); ?></span>
			<?php endif; ?>
		</div>
	</div>
    <div class="article-title">

        <?php
        $args_pl = array(
            'before'           => '<p class="pix-link-pages"><span>'.esc_html__('Pages:', 'irepair').'</span>',
            'after'            => '</p>'
        );
        wp_link_pages($args_pl);
        ?>

        <div class="rtd">
            <?php
            if( get_option('rss_use_excerpt') == 0 && !is_search() ) {
                the_content();
            } else {
                the_excerpt();
            }
            ?>
        </div>

    </div>
<?php
    endif;
