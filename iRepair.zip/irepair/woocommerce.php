<?php
/* Woocommerce template. */
$irepair_id = irepair_woo_get_page_id();
$irepair_isProduct = false;

if ( is_single() && get_post_type() == 'product' ) {
	$irepair_isProduct = true;
}

$irepair_custom = $irepair_id > 0 ? get_post_custom($irepair_id) : array();
$irepair_layout = isset ($irepair_custom['pix_page_layout']) ? reset($irepair_custom['pix_page_layout']) : '2';
$irepair_sidebar = isset ($irepair_custom['pix_selected_sidebar'][0]) ? reset($irepair_custom['pix_selected_sidebar']) : 'sidebar-1';

if ( $irepair_isProduct === true ) {
	$irepair_useSettingsGlobal = irepair_get_option( 'shop_settings_global_product', 'on' );
	if ( $irepair_useSettingsGlobal == 'on' ) {
		$irepair_layout = irepair_get_option( 'shop_settings_sidebar_type', '2');
		$irepair_sidebar = irepair_get_option( 'shop_settings_sidebar_content', 'product-sidebar-1' );
	}
}

if ( ! is_active_sidebar($irepair_sidebar) ) $irepair_layout = '1';

get_header(); ?>


<section class="blog" >
    <div class="container">
		<div class="row">

            <?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>

            <div class="rtd <?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-8<?php endif; ?> col-sm-12 col-xs-12 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?>">

                <?php  woocommerce_content(); ?>

            </div>

            <?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>

		</div>
	</div>
</section>

<?php get_footer();?>
