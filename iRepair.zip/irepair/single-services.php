 <?php /* Template Name: Single Service */ 

$irepair_custom = isset( $wp_query ) ? get_post_custom( $wp_query->get_queried_object_id() ) : '';
$irepair_layout = isset ($irepair_custom['pix_page_layout']) ? $irepair_custom['pix_page_layout'][0] : '2';
$irepair_sidebar = isset ($irepair_custom['pix_selected_sidebar'][0]) ? $irepair_custom['pix_selected_sidebar'][0] : 'services-sidebar-1';

if ( ! is_active_sidebar($irepair_sidebar) ) $irepair_layout = '1';

?>
<?php get_header();?>

<section class="service">
    <div class="container">
        <div class="row">
      
		<?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>
        
        <div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-8<?php endif; ?> col-sm-12 col-xs-12 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?>">
            <section class="service-page">
                <div class="row">

                <?php
                if ( have_posts() ) {
                    while (have_posts()) {
                        the_post();

                        $irepair_thumbnail = get_the_post_thumbnail($post->ID);
                        the_content();

                    }
                }
                ?>

                </div>
            </section>
		</div>

		<?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>

		</div>
	</div>
</section>
<?php get_footer();?>
