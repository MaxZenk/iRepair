<?php
/**
 * The home template file
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Template Name: Blog Template
 *
 */

$irepair_postpage_id = get_option( 'page_for_posts' );
$irepair_frontpage_id = get_option( 'page_on_front' );
$irepair_page_id = isset($wp_query) ? $wp_query->get_queried_object_id() : '';

if ( $irepair_page_id == $irepair_postpage_id && $irepair_postpage_id != $irepair_frontpage_id ) :
	$irepair_custom = isset( $wp_query ) ? get_post_custom( $wp_query->get_queried_object_id() ) : '';
	$irepair_layout = isset( $irepair_custom['pix_page_layout'] ) ? $irepair_custom['pix_page_layout'][0] : '2';
	$irepair_sidebar = isset( $irepair_custom['pix_selected_sidebar'][0] ) ? $irepair_custom['pix_selected_sidebar'][0] : 'sidebar-1';
else :
	$irepair_layout = irepair_get_option('blog_settings_sidebar_type', '2');
	$irepair_sidebar = irepair_get_option('blog_settings_sidebar_content', 'sidebar-1');
endif;

if ( ! is_active_sidebar($irepair_sidebar) ) $irepair_layout = '1';

?>
<?php get_header();?>

<section class="blog-content-section" id="main">
<div class="container">
	<div class="row">

		<?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>
		
		<div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-9 col-md-8<?php endif; ?> col-sm-12 col-xs-12 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?>">
		
			<main class="main-content">
			
				<?php
                    $wp_query = new WP_Query();
                    $pp = get_option('posts_per_page');
                    $wp_query->query('posts_per_page='.$pp.'&paged='.$paged);
                    get_template_part( 'loop', 'index' );
                ?>
                <?php the_posts_pagination( array(
                    'prev_text'          => esc_html__( '&lt;', 'irepair' ),
                    'next_text'          => esc_html__( '&gt;', 'irepair' ),
                    'screen_reader_text' => esc_html__( '&nbsp;', 'irepair'),
                    'type' => 'list'
                ) ); ?>

			</main><!-- end main-content -->
			
		</div><!-- end col -->

		<?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>

	</div><!-- end row -->
</div>
</section>
<?php get_footer(); ?>
