/*global wc_enhanced_select_params */

(function( $ ) {
	"use strict";
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.admin-color-field').wpColorPicker();
    });

})( jQuery );

