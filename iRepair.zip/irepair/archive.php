<?php

$irepair_layout = irepair_get_option('blog_settings_sidebar_type', '2');
$irepair_sidebar = irepair_get_option('blog_settings_sidebar_content', 'sidebar-1');


if ( ! is_active_sidebar($irepair_sidebar) ) $irepair_layout = '1';

    $custom = isset ($wp_query) ? get_post_custom($wp_query->get_queried_object_id()) : '';
?>

<?php get_header(); ?>

<section class="blog-content-section" id="main">
	<div class="container">
	    <div class="row">
	        <?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>
	        <div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-8<?php endif; ?> col-sm-12 col-xs-12 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?>">
	            <?php if ( have_posts() ) : ?>

                     <?php
                         if ( have_posts() )
                            the_post();
                         rewind_posts();
                         get_template_part( 'loop', 'archive' );
                     ?>

                <?php endif ?>
				
                <?php
                    the_posts_pagination( array(
                        'prev_text'          => wp_kses_post(__( '<i class="fa fa-chevron-left"></i>', 'irepair' )),
                        'next_text'          => wp_kses_post(__( '<i class="fa fa-chevron-right"></i>', 'irepair' )),
                        'screen_reader_text' => esc_html__( '&nbsp;', 'irepair'),
                    ) );
                ?>
				
	        </div>
	        <?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>
	    </div>
	</div>
</section>

<?php get_footer(); ?>