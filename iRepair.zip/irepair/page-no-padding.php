<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Template Name: Page No Padding
 *
 */

$irepair_custom = isset( $wp_query ) ? get_post_custom( $wp_query->get_queried_object_id() ) : '';
$irepair_layout = isset( $irepair_custom['pix_page_layout'] ) ? $irepair_custom['pix_page_layout'][0] : '2';
$irepair_sidebar = isset( $irepair_custom['pix_selected_sidebar'][0] ) ? $irepair_custom['pix_selected_sidebar'][0] : 'sidebar-1';

if ( ! is_active_sidebar($irepair_sidebar) ) $irepair_layout = '1';

?>

<?php get_header();?>
    <section class="blog pix-page-no-padding" >
        <div class="container">
            <div class="row">
            
                <?php irepair_show_sidebar( 'left', $irepair_layout, $irepair_sidebar ); ?>

				<div class="<?php if ( $irepair_layout == 1 ) : ?>col-lg-12 col-md-12<?php else : ?>col-lg-8 col-md-8 left-column sidebar-type-<?php echo esc_attr($irepair_layout); ?><?php endif; ?> col-sm-12 col-xs-12">

                    <div class="rtd"> <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
                    <?php $irepair_page_com_id = $post; ?>
                    <?php the_content(); ?>
                    <?php
                    if('open' == $irepair_page_com_id->comment_status) {
                        comments_template();
                    }
                    ?>
                    <?php endwhile; ?>
                    </div>
                </div>
                
                <?php irepair_show_sidebar( 'right', $irepair_layout, $irepair_sidebar ); ?>
                
            </div>
        </div>
    </section>
<?php get_footer(); ?>