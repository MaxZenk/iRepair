<?php

	$post_ID = isset ($wp_query) ? $wp_query->get_queried_object_id() : (get_the_ID()>0 ? get_the_ID() : '');

    if( class_exists( 'WooCommerce' ) && irepair_is_woo_page() && irepair_get_option('woo_header_global','1') ){
		$post_ID = get_option( 'woocommerce_shop_page_id' ) ? get_option( 'woocommerce_shop_page_id' ) : $post_ID;
	} elseif (!is_page_template('page-home.php') && get_option('page_for_posts') != ''){
		$post_ID = get_option('page_for_posts') ? get_option('page_for_posts') : 0;
	}

	$irepair_header = apply_filters('irepair_header_settings', $post_ID);

	$logo = irepair_get_option('general_settings_logo');
	$logo_text = irepair_get_option('general_settings_logo_text');

	$topFooterBlockId = false;
	$bottomFooterBlockId = false;

	$topFooterBlockId = in_array(get_post_meta($post_ID, 'pix_page_top_footer_staticblock', true), array('global', '')) || $post_ID == '' ? irepair_get_option('footer_block_top') : get_post_meta($post_ID, 'pix_page_top_footer_staticblock', true);
	$bottomFooterBlockId = in_array(get_post_meta($post_ID, 'pix_page_footer_staticblock', true), array('global', '')) || $post_ID == '' ? irepair_get_option('footer_block') : get_post_meta($post_ID, 'pix_page_footer_staticblock', true);

	if(function_exists('icl_object_id')) {
		$topFooterBlockId = icl_object_id ($topFooterBlockId,'staticblocks',true);
		$bottomFooterBlockId = icl_object_id ($bottomFooterBlockId,'staticblocks',true);
	}

?>

<?php if ( ($topFooterBlockId != 'nofooter' || $bottomFooterBlockId != 'nofooter') && get_post_type() != 'staticblocks' ) : ?>

    <!-- Footer section -->
    <footer class="pix-footer">
        <div class="container">

            <?php if ( $topFooterBlockId && $topFooterBlockId !='nofooter' )  { irepair_get_staticblock_content($topFooterBlockId); } ?>
            <?php if ( $bottomFooterBlockId && $bottomFooterBlockId !='nofooter' ) { irepair_get_staticblock_content($bottomFooterBlockId); } ?>

            <?php if ( !$topFooterBlockId && !$bottomFooterBlockId ):?>
                <div class="pix-footer__bottom">
                <?php if(irepair_get_option('footer_copyright', '')) : ?>
                    <div class="footer-copyright"><?php echo wp_kses_post(irepair_get_option('footer_copyright'))?></div>
                <?php endif; ?>
                    <div class="footer-copyright"><?php esc_html_e('&copy; 2020 ', 'irepair')?><span><?php esc_html_e('Все права защищены', 'irepair')?></span></div>
                    <div class="footer-created_by"><a target="_blank" href="<?php echo esc_url('https://true-emotions.studio')?>"><span><?php esc_html_e('PixTheme', 'irepair')?></span><?php esc_html_e(' Studio', 'irepair')?></a></div>
                </div>
            <?php endif; ?>

        </div>
    </footer>

<?php endif; ?>


</div>

<?php
    wp_footer();
?>
</body></html>