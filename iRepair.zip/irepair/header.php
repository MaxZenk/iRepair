<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, user-scalable=no">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="x-rim-auto-match" content="none">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<!-- <link href="irepair-child/css/all.css" rel="stylesheet"> -->
<?php wp_head(); ?>

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-FHXS3XGZ41"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', 'G-FHXS3XGZ41');
	</script>
	<!-- /Google Analytics -->

	<!-- Yandex.Metrika counter -->
	<script type="text/javascript" >
		(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
		m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
		(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

		ym(75415048, "init", {
			clickmap:true,
			trackLinks:true,
			accurateTrackBounce:true,
			webvisor:true
		});
	</script>

	<noscript>
		<div><img src="https://mc.yandex.ru/watch/75415048" style="position:absolute; left:-9999px;" alt="" /></div>
	</noscript>
	<!-- /Yandex.Metrika counter -->

	<!-- Google AdSense counter -->
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1352156447421794" crossorigin="anonymous"></script>
	<!-- /Google AdSense counter -->
</head>

<body <?php body_class(); ?>  data-scrolling-animations="true">

<?php
	$post_ID = isset ($wp_query) ? $wp_query->get_queried_object_id() : get_the_ID();
	$irepair_page_layout = get_post_meta($post_ID, 'page_layout', 1) != '' ? get_post_meta($post_ID, 'page_layout', 1) : irepair_get_option('style_general_settings_layout', 'normal');
    if( class_exists( 'WooCommerce' ) ){
		$post_ID = $post_ID ? $post_ID : get_option( 'woocommerce_shop_page_id' );
	}
	$irepair_woo_layout = get_post_meta($post_ID, 'pix_woo_layout', 1) != '' ? get_post_meta($post_ID, 'pix_woo_layout', 1) : irepair_get_option('woo_layout', 'default');

	$irepair_header = apply_filters('irepair_header_settings', $post_ID);

?>

<?php if( (irepair_get_option('general_settings_loader','useall') == 'usemain' && is_front_page()) || irepair_get_option('general_settings_loader','useall') == 'useall' ) : ?>
<!-- Loader -->
	<div id="page-preloader"><div class="pix-pulse"></div></div>
<!-- Loader end -->
<?php endif; ?>





<div class="wrapper layout animated-css page-layout-<?php echo esc_attr($irepair_page_layout); ?> woo-layout-<?php echo esc_attr($irepair_woo_layout); ?>" >

    <?php irepair_get_theme_header('mobile'); ?>


<?php
    irepair_get_theme_header($irepair_header['header_type']);

	if (!is_page_template('page-home.php')) {
		irepair_load_block('header/bg_image');
	}
?>








