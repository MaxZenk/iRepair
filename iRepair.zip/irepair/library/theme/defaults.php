<?php 
/**  Theme defaults values  **/

add_action('after_setup_theme', 'irepair_theme_defaults');
function irepair_theme_defaults(){

	// Logo
	update_option( 'irepair_default_logo_width', '146' );
	update_option( 'irepair_default_logo_height', '120' );

	// Header
    update_option( 'irepair_default_header_menu_background', 'main-color' );

	// Colors and Fonts
	update_option( 'irepair_default_main_color', '#2052c9' );
	update_option( 'irepair_default_gradient_color', '#21a5dd' );
	update_option( 'irepair_default_gradient_direction', 'to right' );
	update_option( 'irepair_default_additional_color', '#3794f2' );

	update_option( 'irepair_default_fonts', '{"648":"Poppins:400,600,700"}');
	update_option( 'irepair_default_font', 'Poppins' );
	update_option( 'irepair_default_font_weight', '400' );
	update_option( 'irepair_default_font_size', '14' );
	update_option( 'irepair_default_title', 'Poppins' );
	update_option( 'irepair_default_title_weight', '600' );
	update_option( 'irepair_default_title_size', '35' );
	update_option( 'irepair_default_subtitle', 'Poppins' );
	update_option( 'irepair_default_subtitle_weight', '600' );
	update_option( 'irepair_default_subtitle_size', '17' );

	// Header Title and Breadcrumbs
	update_option( 'irepair_default_tab_bg_color', '#191919' );
	update_option( 'irepair_default_tab_bg_color_gradient', '#303030' );
	update_option( 'irepair_default_tab_gradient_direction', 'to top left' );
	update_option( 'irepair_default_tab_bg_opacity', '80' );
	update_option( 'irepair_default_tab_padding_top', '170' );
	update_option( 'irepair_default_tab_padding_bottom', '120' );
    update_option( 'irepair_default_tab_margin_bottom', '100' );

	update_option( 'irepair_default_decor', '1' );

}

add_filter( 'irepair_header_settings', 'irepair_header_settings_var' );
function irepair_header_settings_var( $post_ID=0 ){

	/// Header global parameters
    $irepair['header_type'] = irepair_get_option('header_type', 'header1');
    $irepair['header_background'] = irepair_get_option('header_background', 'black');
    $irepair['header_transparent'] = irepair_get_option('header_transparent', '0');
    $irepair['top_bar_background'] = irepair_get_option('top_bar_background', 'black');
    $irepair['top_bar_transparent'] = irepair_get_option('top_bar_transparent', '100');
    $irepair['header_layout'] = irepair_get_option('header_layout', 'container');
    $irepair['header_bar'] = irepair_get_option('header_bar', '0');
    $irepair['header_sticky'] = irepair_get_option('header_sticky', 'sticky');
    $irepair['header_menu_pos'] = irepair_get_option('header_menu_pos', '');


    /// Header menu settings
    $irepair['header_menu'] = irepair_get_option('header_menu', '1');

    /// Header widgets
    $irepair['header_minicart'] = irepair_get_option('header_minicart', '1');
    $irepair['header_search'] = irepair_get_option('header_search', '1');
    $irepair['header_socials'] = irepair_get_option('header_socials', '1');
    $irepair['header_button'] = irepair_get_option('header_button', '0');

    $irepair['header_phone'] = irepair_get_option('header_phone', '');
    $irepair['header_email'] = irepair_get_option('header_email', '');

    /// Responsive
    $irepair['mobile_sticky'] = irepair_get_option('mobile_sticky', '');
    $irepair['mobile_topbar'] = irepair_get_option('mobile_topbar', '');
    $irepair['tablet_minicart'] = irepair_get_option('tablet_minicart', '');
    $irepair['tablet_search'] = irepair_get_option('tablet_search', '');
    $irepair['tablet_phone'] = irepair_get_option('tablet_phone', '');
    $irepair['tablet_socials'] = irepair_get_option('tablet_socials', '');


    /// Logo
    $irepair['logo'] = irepair_get_option('general_settings_logo', '');


	return $irepair;
	
}