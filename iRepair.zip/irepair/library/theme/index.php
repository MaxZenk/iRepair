<?php 
	/**  Theme_index  **/

	/* Define library Theme path */

    include_once( get_template_directory() . '/library/theme/styles_scripts.php' );
    include_once( get_template_directory() . '/library/theme/functions.php' );
    include_once( get_template_directory() . '/library/theme/blog.php' );
    include_once( get_template_directory() . '/library/theme/import.php' );
    include_once( get_template_directory() . '/library/theme/comment_walker.php' );
    include_once( get_template_directory() . '/library/theme/menu_walker.php' );
    include_once( get_template_directory() . '/library/theme/portfolio_walker.php' );
    include_once( get_template_directory() . '/library/theme/woo.php' );
    include_once( get_template_directory() . '/library/theme/defaults.php' );


	add_action('after_setup_theme', 'irepair_theme_support_setup');
	function irepair_theme_support_setup(){
	    add_theme_support( 'woocommerce', array(
	        'single_image_width'            => 600,
            'thumbnail_image_width'         => 400,
            'gallery_thumbnail_image_width' => 300,
        ) );
		//add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
		add_image_size('irepair-thumb', 200, 110, true);
		// Define various thumbnail sizes
		$width = ( ( irepair_get_option( 'portfolio_settings_thumb_width', '555' ) ) &&
					 is_numeric( irepair_get_option( 'portfolio_settings_thumb_width', '555' ) ) &&
					 irepair_get_option( 'portfolio_settings_thumb_width', '555' ) > 0
				 ) ? irepair_get_option( 'portfolio_settings_thumb_width', '555' ) : 555;
		$height = ( ( irepair_get_option( 'portfolio_settings_thumb_height', '555' ) ) &&
					 is_numeric( irepair_get_option( 'portfolio_settings_thumb_height', '555' ) ) &&
					 irepair_get_option( 'portfolio_settings_thumb_height', '555' ) > 0
				 ) ? irepair_get_option( 'portfolio_settings_thumb_height', '555' ) : 555;
		add_image_size('irepair-portfolio-thumb', $width, $height, true);
		add_image_size('irepair-blog-thumb', 825, 411, true);
		add_image_size('irepair-services-thumb', 350, 233, true);
		add_image_size('irepair-post-thumb', 400, 560, true);
	}

	if ( ! isset( $content_width ) ) {
		$content_width = 1200;
	}

?>