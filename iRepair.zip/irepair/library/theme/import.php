<?php

add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

function irepair_import_files() {
    return array(
        array(
            'import_file_name'           => esc_html__( 'iRepair', 'irepair' ),
            'import_file_url'            => esc_url('https://data.true-emotions.studio/themes/irepair/irepair.xml'),
            'import_widget_file_url'     => '',
            'import_customizer_file_url' => esc_url('https://data.true-emotions.studio/themes/irepair/irepair.dat'),
            'import_preview_image_url'   => esc_url('https://data.true-emotions.studio/themes/irepair/irepair.jpg'),
            'preview_url'                => esc_url('https://irepair.true-emotions.studio/'),
        ),

    );
}
add_filter( 'pt-ocdi/import_files', 'irepair_import_files' );

function irepair_after_import( $selected_import ) {
    global $wp_filesystem;

    $menu_arr = array();
    $main_menu = get_term_by('name', 'Main', 'nav_menu');
    if(is_object($main_menu))
        $menu_arr['primary_nav'] = $main_menu->term_id;
    set_theme_mod( 'nav_menu_locations', $menu_arr );
    
    if(function_exists('vc_set_default_editor_post_types')){
        $vc_list = array(
            'page',
            'post',
            'portfolio',
            'services',
            'staticblocks',
        );
        vc_set_default_editor_post_types( $vc_list );
    }

    $slider_array = array(get_template_directory()."/library/revslider/iRepair-1.zip",
                            get_template_directory()."/library/revslider/iRepair-2.zip",
                            get_template_directory()."/library/revslider/iRepair-3.zip");

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );
    set_theme_mod( 'irepair_footer_block', '2919' );

    $absolute_path = __FILE__;
    $path_to_file = explode( 'wp-content', $absolute_path );
    $path_to_wp = $path_to_file[0];

    require_once( $path_to_wp.'/wp-load.php' );
    require_once( $path_to_wp.'/wp-includes/functions.php');

    $slider = new RevSlider();

    foreach($slider_array as $filepath){
        $slider->importSliderFromPost(true,true,$filepath);
    }

}
add_action( 'pt-ocdi/after_import', 'irepair_after_import' );

?>