<?php
/**  Core_Modules  **/

/* Define library CORE MODULES path */


$allowedModules = array(
    'vc_icons_loader',
);


irepair_load_modules($allowedModules);



?>