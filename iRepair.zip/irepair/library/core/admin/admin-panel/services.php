<?php
function irepair_customize_services_tab($wp_customize, $theme_name) {

	$wp_customize->add_section( 'irepair_services_settings' , array(
        'title'      => esc_html__( 'Services', 'irepair' ),
        'priority'   => 60,
    ) );

	$wp_customize->add_setting( 'irepair_services_settings_page', array(
		'default'           => '0',
		'transport'         => 'postMessage',
		'sanitize_callback' => 'absint'
	) );

	$wp_customize->add_setting( 'irepair_services_settings_related', array(
			'default'           => 1,
			'transport'         => 'postMessage',
			'sanitize_callback' => 'esc_attr'
	) );

	$wp_customize->add_setting( 'irepair_services_settings_share', array(
		'default'           => 1,
		'transport'         => 'postMessage',
		'sanitize_callback' => 'esc_attr'
	) );


	$wp_customize->add_control( 'irepair_services_settings_page', array(
		'label'    => esc_html__( 'Select Page For All Services', 'irepair' ),
		'section'  => 'irepair_services_settings',
		'type'     => 'dropdown-pages'
	) );

	$wp_customize->add_control( 'irepair_services_settings_related', array(
        'label'    => esc_html__( 'Display Related Services', 'irepair' ),
        'section'  => 'irepair_services_settings',
        'settings' => 'irepair_services_settings_related',
        'type'     => 'select',
        'choices'  => array(
            '1' => esc_html__( 'On', 'irepair' ),
            '0'  => esc_html__( 'Off', 'irepair' ),
        ),
        'priority'   => 20
	) );

    $wp_customize->add_control( 'irepair_services_settings_share', array(
            'label'    => esc_html__( 'Display Share on Services', 'irepair' ),
            'section'  => 'irepair_services_settings',
            'settings' => 'irepair_services_settings_share',
            'type'     => 'select',
            'choices'  => array(
                '1' => esc_html__( 'On', 'irepair' ),
                '0'  => esc_html__( 'Off', 'irepair' ),
            ),
            'priority'   => 30
    ) );

}