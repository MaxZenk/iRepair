<?php
    function irepair_customize_blog_tab($wp_customize, $theme_name){

        $wp_customize->add_section( 'irepair_blog_settings' , array(
            'title'      => esc_html__( 'Blog', 'irepair' ),
            'priority'   => 65,
        ) );


        $wp_customize->add_setting( 'irepair_blog_settings_type' , array(
			'default'     => 'classic',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );

        $wp_customize->add_control(
            'irepair_blog_settings_type',
            array(
                'label'    => esc_html__( 'Blog display type', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_type',
                'type'     => 'select',
                'choices'  => array(
                    'classic'  => esc_html__( 'Classic', 'irepair' ),
                    'grid' => esc_html__( 'Grid', 'irepair' ),
                ),
                'priority'   => 10
            )
        );


        $wp_customize->add_setting( 'irepair_blog_settings_date' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );
        
		$wp_customize->add_setting( 'irepair_blog_settings_author_name' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );

		$wp_customize->add_setting( 'irepair_blog_settings_author' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );

		$wp_customize->add_setting( 'irepair_blog_settings_comments' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );

        $wp_customize->add_setting( 'irepair_blog_settings_categories' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );

		$wp_customize->add_setting( 'irepair_blog_settings_tags' , array(
			'default'     => '1',
			'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_attr',
		) );
		
        $wp_customize->add_setting( 'irepair_blog_settings_share' , array(
            'default'     => '1',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr',
        ) );
        
        $wp_customize->add_setting( 'irepair_blog_settings_readmore' , array(
            'default'     => esc_html__( 'Read more', 'irepair' ),
            'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_html',
        ) );


        $wp_customize->add_control(
            'irepair_blog_settings_date',
            array(
                'label'    => esc_html__( 'Display Date on blog posts', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_date',
                'type'     => 'select',
                'choices'  => array(
                    '0'  => esc_html__( 'Off', 'irepair' ),
                    '1' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 50
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_author_name',
            array(
                'label'    => esc_html__( 'Display Author name on blog page and single post', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_author_name',
                'type'     => 'select',
                'choices'  => array(
                    '0'  => esc_html__( 'Off', 'irepair' ),
                    '1' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 60
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_author',
            array(
                'label'    => esc_html__( 'Display About Author block on single post', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_author',
                'type'     => 'select',
                'choices'  => array(
                    '0'  => esc_html__( 'Off', 'irepair' ),
                    '1' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 70
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_comments',
            array(
                'label'    => esc_html__( 'Display Comments on single post', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_comments',
                'type'     => 'select',
                'choices'  => array(
                    '0'  => esc_html__( 'Off', 'irepair' ),
                    '1' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 80
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_categories',
            array(
                'label'    => esc_html__( 'Display Categories', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_categories',
                'type'     => 'select',
                'choices'  => array(
                    '0'  => esc_html__( 'Off', 'irepair' ),
                    '1' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 90
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_tags',
            array(
                'label'    => esc_html__( 'Display Tags', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_tags',
                'type'     => 'select',
                'choices'  => array(
                    'off'  => esc_html__( 'Off', 'irepair' ),
                    'on' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 100
            )
        );
        
        $wp_customize->add_control(
            'irepair_blog_settings_share',
            array(
                'label'    => esc_html__( 'Display share buttons on single post', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_share',
                'type'     => 'select',
                'choices'  => array(
                    'off'  => esc_html__( 'Off', 'irepair' ),
                    'on' => esc_html__( 'On', 'irepair' ),
                ),
                'priority'   => 110
            )
        );
        


        $wp_customize->add_control(
            'irepair_blog_settings_readmore',
            array(
                'label'    => esc_html__( 'Read More button text', 'irepair' ),
                'section'  => 'irepair_blog_settings',
                'settings' => 'irepair_blog_settings_readmore',
                'type'     => 'textfield',
                'priority'   => 10
            )
        );


    }
?>