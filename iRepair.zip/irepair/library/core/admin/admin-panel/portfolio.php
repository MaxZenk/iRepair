<?php

function irepair_customize_portfolio_tab($wp_customize, $theme_name) {

	$wp_customize->add_panel('irepair_portfolio_settings',
	array(
		'title' => esc_html__( 'Team', 'irepair' ),
		'priority' => 55,
		)
	);

	// portfolio general settings
	$wp_customize->add_section( 'irepair_portfolio_general_settings' , array(
		'title'      => esc_html__( 'General', 'irepair' ),
		'priority'   => 10,
		'panel' => 'irepair_portfolio_settings'
	) );


	$wp_customize->add_setting( 'irepair_portfolio_settings_thumb_width' , array(
		'default'     => '555',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_settings_thumb_width',
		array(
			'label'    => esc_html__( 'Tumbnails Width (px)', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_settings_thumb_width',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: 555px', 'irepair' ),
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_thumb_height' , array(
		'default'     => '555',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_settings_thumb_height',
		array(
			'label'    => esc_html__( 'Tumbnails Height (px)', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_settings_thumb_height',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: 555px', 'irepair' ),
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_slug' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_slug',
		array(
			'label'    => esc_html__( 'Url Slug', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_slug',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: team', 'irepair' ),
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_label' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_label',
		array(
			'label'    => esc_html__( 'Label', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_label',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: Team', 'irepair' ),
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_cat_slug' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_cat_slug',
		array(
			'label'    => esc_html__( 'Url Category Slug', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_cat_slug',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: specialty', 'irepair' ),
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_cat_label' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_absinteger'
	) );
	$wp_customize->add_control(
		'irepair_portfolio_cat_label',
		array(
			'label'    => esc_html__( 'Categories Label', 'irepair' ),
			'section'  => 'irepair_portfolio_general_settings',
			'settings' => 'irepair_portfolio_cat_label',
			'type'     => 'textfield',
			'description' => esc_html__( 'Default: Specialties', 'irepair' ),
		)
	);


	// portfolio categories page settings
	$wp_customize->add_section( 'irepair_portfolio_categories_settings' , array(
		'title'      => esc_html__( 'Category and Archive Pages', 'irepair' ),
		'priority'   => 20,
		'panel' => 'irepair_portfolio_settings'
	) );

	$wp_customize->add_setting( 'irepair_portfolio_settings_type' , array(
		'default'     => 'type_without_icons',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_portfolio_type'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_type',
		array(
			'label'    => esc_html__( 'Item type', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_type',
			'description' => esc_html__( 'display type', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'type_without_icons' => esc_html__( 'Without over icons with space', 'irepair' ),
				'type_without_space' => esc_html__( 'Without over icons and space', 'irepair' ),
				'type_with_icons' => esc_html__( 'With over icons', 'irepair' ),
			),
			'priority' => 10
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_perrow' , array(
		'default'     => '2',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_portfolio_perrow'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_perrow',
		array(
			'label'    => esc_html__( 'Column Number', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_perrow',
			'description' => esc_html__( 'Items per row for category and archive pages.', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'2' => esc_html__( '2 columns', 'irepair' ),
				'3' => esc_html__( '3 columns', 'irepair' ),
				'4' => esc_html__( '4 columns', 'irepair' ),
			),
			'priority' => 20
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_perpage' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_per_page'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_perpage',
		array(
			'label'    => esc_html__( 'Items per page', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_perpage',
			'description' => esc_html__( 'Leave empty to show all items.', 'irepair' ),
			'type'     => 'textfield',
			'priority' => 30
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_sidebar_type' , array(
		'default'     => '2',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_sidebar_portfolio_type'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_sidebar_type',
		array(
			'label'    => esc_html__( 'Sidebar type', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_sidebar_type',
			'description' => esc_html__( 'Select sidebar type for category and archive pages.', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'1' => esc_html__( 'Full width', 'irepair' ),
				'2' => esc_html__( 'Right Sidebar', 'irepair' ),
				'3' => esc_html__( 'Left Sidebar', 'irepair' ),
			),
			'priority' => 40
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_sidebar_content' , array(
		'default'     => 'sidebar-1',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_sidebar_portfolio_content'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_sidebar_content',
		array(
			'label'    => esc_html__( 'Sidebar content', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_sidebar_content',
			'description' => esc_html__( 'Select sidebar content for category and archive pages.', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'sidebar-1' => esc_html__( 'WP Default Sidebar', 'irepair' ),
				'global-sidebar-1' => esc_html__( 'Blog Sidebar', 'irepair' ),
				'portfolio-sidebar-1' => esc_html__( 'Portfolio Sidebar', 'irepair' ),
				'custom-area-1' => esc_html__( 'Custom Area', 'irepair' ),
			),
			'priority' => 50
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_loadmore' , array(
		'default'     => esc_html__('Load more', 'irepair' ),
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_text'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_loadmore',
		array(
			'label'    => esc_html__( 'Load More button text', 'irepair' ),
			'section'  => 'irepair_portfolio_categories_settings',
			'settings' => 'irepair_portfolio_settings_loadmore',
			'type'     => 'textfield',
			'priority' => 60
		)
	);


	// portfolio single page settings
	$wp_customize->add_section( 'irepair_portfolio_single_settings' , array(
		'title'      => esc_html__( 'Single Page', 'irepair' ),
		'priority'   => 30,
		'panel' => 'irepair_portfolio_settings'
	) );

	$wp_customize->add_setting( 'irepair_portfolio_settings_related_show' , array(
		'default'     => 'on',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_onoff'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_related_show',
		array(
			'label'    => esc_html__( 'Show block Related', 'irepair' ),
			'section'  => 'irepair_portfolio_single_settings',
			'settings' => 'irepair_portfolio_settings_related_show',
			'description' => esc_html__( 'Select on/off Related for single page.', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'on' => esc_html__( 'On', 'irepair' ),
				'off' => esc_html__( 'Off', 'irepair' ),
			),
			'priority' => 10
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_related_title' , array(
		'default'     => esc_html__('Related', 'irepair' ),
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_text'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_related_title',
		array(
			'label'    => esc_html__( 'Title block Related', 'irepair' ),
			'section'  => 'irepair_portfolio_single_settings',
			'settings' => 'irepair_portfolio_settings_related_title',
			'type'     => 'textfield',
			'priority' => 20
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_related_desc' , array(
		'default'     => '',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_text'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_related_desc',
		array(
			'label'    => esc_html__( 'Description block Related', 'irepair' ),
			'section'  => 'irepair_portfolio_single_settings',
			'settings' => 'irepair_portfolio_settings_related_desc',
			'type'     => 'textarea',
			'priority' => 30
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_share' , array(
		'default'     => 'on',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'irepair_sanitize_onoff'
	) );

	$wp_customize->add_control(
		'irepair_portfolio_settings_share',
		array(
			'label'    => esc_html__( 'Show share', 'irepair' ),
			'section'  => 'irepair_portfolio_single_settings',
			'settings' => 'irepair_portfolio_settings_share',
			'description' => esc_html__( 'Select on/off share for single pages.', 'irepair' ),
			'type'     => 'select',
			'choices'  => array(
				'on' => esc_html__( 'On', 'irepair' ),
				'off' => esc_html__( 'Off', 'irepair' ),
			),
			'priority' => 40
		)
	);

	$wp_customize->add_setting( 'irepair_portfolio_settings_link_to_all' , array(
		'default'     => '0',
		'transport'   => 'postMessage',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( 'irepair_portfolio_settings_page', array(
		'label'    => esc_html__( 'Select Page For All Portfolio', 'irepair' ),
		'section'  => 'irepair_portfolio_single_settings',
		'settings' => 'irepair_portfolio_settings_link_to_all',
		'type'     => 'dropdown-pages',
		'priority' => 50
	) );


}