<?php

	function irepair_customize_header_tab($wp_customize, $theme_name){

		$wp_customize->add_panel('irepair_header_panel',  array(
            'title' => 'Header',
            'priority' => 30,
            )
        );



		$wp_customize->add_section( 'irepair_header_settings' , array(
		    'title'      => esc_html__( 'General Settings', 'irepair' ),
		    'priority'   => 5,
			'panel' => 'irepair_header_panel'
		) );


		$wp_customize->add_setting( 'irepair_header_type' , array(
				'default'     => 'header1',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_type',
            array(
                'label'    => esc_html__( 'Type', 'irepair' ),
                'section'  => 'irepair_header_settings',
                'settings' => 'irepair_header_type',
                'type'     => 'select',
                'choices'  => array(
                    'header1' => esc_html__( 'Default', 'irepair' ),
                    'header2' => esc_html__( 'Centered Logo', 'irepair' ),
//		            'header3' => esc_html__( 'Centered Logo (2 levels)', 'irepair' ),
		            'header4' => esc_html__( 'Header Info (2 levels)', 'irepair' ),
//		            'header5' => esc_html__( 'Slideout Sidebar', 'irepair' ),
                ),
            )
        );

		$wp_customize->add_setting( 'irepair_header_layout' , array(
			'default'     => 'container',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_layout',
            array(
                'label'    => esc_html__( 'Layout', 'irepair' ),
                'section'  => 'irepair_header_settings',
                'settings' => 'irepair_header_layout',
                'type'     => 'select',
                'choices'  => array(
                    'container'  => esc_html__( 'Normal', 'irepair' ),
		            'container-fluid' => esc_html__( 'Full Width', 'irepair' ),
                ),
            )
        );

		$wp_customize->add_setting( 'irepair_header_sticky' , array(
				'default'     => 'sticky',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_sticky',
            array(
                'label'         => esc_html__( 'Sticky', 'irepair' ),
                'section'       => 'irepair_header_settings',
                'settings'      => 'irepair_header_sticky',
                'type'          => 'select',
                'choices'       => array(
                    '' => esc_html__( 'No', 'irepair' ),
                    'sticky'  => esc_html__( 'Yes', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_header_menu_pos' , array(
				'default'     => '',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_menu_pos',
            array(
                'label'    => esc_html__( 'Menu Position', 'irepair' ),
                'description'   => '',
                'section'  => 'irepair_header_settings',
                'settings' => 'irepair_header_menu_pos',
                'type'     => 'select',
                'choices'  => array(
                    '' => esc_html__( 'Default', 'irepair' ),
                    'pix-text-center'  => esc_html__( 'Center', 'irepair' ),
                ),
            )
        );



		/// HEADER STYLE ///

		$wp_customize->add_section( 'irepair_header_settings_style' , array(
		    'title'      => esc_html__( 'Colors', 'irepair' ),
		    'priority'   => 10,
			'panel' => 'irepair_header_panel'
		) );


		$wp_customize->add_setting( 'irepair_top_bar_background' , array(
				'default'     => 'black',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_top_bar_background',
            array(
                'label'    => esc_html__( 'Top Bar Background Color', 'irepair' ),
                'section'  => 'irepair_header_settings_style',
                'settings' => 'irepair_top_bar_background',
                'type'     => 'select',
                'choices'  => array(
                    'white' => esc_html__( 'White', 'irepair' ),
		            'black' => esc_html__( 'Black', 'irepair' ),
                ),
            )
        );

		$wp_customize->add_setting( 'irepair_top_bar_transparent' , array(
			'default'     => '100',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'esc_attr'
		) );
		$wp_customize->add_control(
			new iRepair_Slider_Single_Control(
				$wp_customize,
				'irepair_top_bar_transparent',
				array(
					'label' => esc_html__( 'Top Bar Transparent', 'irepair' ),
					'section' => 'irepair_header_settings_style',
					'settings' => 'irepair_top_bar_transparent',
					'min' => 0,
					'max' => 100,
					'unit'=> '%',
				)
			)
	    );

		$wp_customize->add_setting( 'irepair_header_background' , array(
				'default'     => 'white',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_background',
            array(
                'label'    => esc_html__( 'Background Color', 'irepair' ),
                'section'  => 'irepair_header_settings_style',
                'settings' => 'irepair_header_background',
                'type'     => 'select',
                'choices'  => array(
                    'white' => esc_html__( 'White', 'irepair' ),
		            'black' => esc_html__( 'Black', 'irepair' ),
                ),
            )
        );

		$wp_customize->add_setting( 'irepair_header_transparent' , array(
			'default'     => '100',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'esc_attr'
		) );
		$wp_customize->add_control(
			new iRepair_Slider_Single_Control(
				$wp_customize,
				'irepair_header_transparent',
				array(
					'label' => esc_html__( 'Transparent', 'irepair' ),
					'section' => 'irepair_header_settings_style',
					'settings' => 'irepair_header_transparent',
					'min' => 0,
					'max' => 100,
					'unit'=> '%',
				)
			)
	    );

		$wp_customize->add_setting( 'irepair_header_menu_background' , array(
				'default'     => get_option('irepair_default_header_menu_background'),
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_menu_background',
            array(
                'label'    => esc_html__( 'Menu Background Color', 'irepair' ),
                'section'  => 'irepair_header_settings_style',
                'settings' => 'irepair_header_menu_background',
                'type'     => 'select',
                'choices'  => array(
                    'white' => esc_html__( 'White', 'irepair' ),
		            'black' => esc_html__( 'Black', 'irepair' ),
                    'main-color' => esc_html__( 'Main Color', 'irepair' ),
                    'add-color' => esc_html__( 'Additional Color', 'irepair' ),
                    'gradient' => esc_html__( 'Gradient', 'irepair' ),
                ),
            )
        );

		$wp_customize->add_setting( 'irepair_header_menu_transparent' , array(
			'default'     => '100',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'esc_attr'
		) );
		$wp_customize->add_control(
			new iRepair_Slider_Single_Control(
				$wp_customize,
				'irepair_header_menu_transparent',
				array(
					'label' => esc_html__( 'Menu Transparent', 'irepair' ),
					'section' => 'irepair_header_settings_style',
					'settings' => 'irepair_header_menu_transparent',
					'min' => 0,
					'max' => 100,
					'unit'=> '%',
				)
			)
	    );



        /// HEADER ELEMENTS ///

		$wp_customize->add_section( 'irepair_header_settings_elements' , array(
		    'title'      => esc_html__( 'Elements', 'irepair' ),
		    'priority'   => 15,
			'panel' => 'irepair_header_panel'
		) );


		$wp_customize->add_setting( 'irepair_header_bar' , array(
				'default'     => '0',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
			'irepair_header_bar',
			array(
				'label'    => esc_html__( 'Top Bar', 'irepair' ),
				'section'  => 'irepair_header_settings_elements',
				'settings' => 'irepair_header_bar',
				'type'     => 'select',
				'choices'  => array(
						'1'  => esc_html__( 'On', 'irepair' ),
						'0' => esc_html__( 'Off', 'irepair' ),
				),
				'priority'   => 10
			)
		);

		$wp_customize->add_setting( 'irepair_header_minicart' , array(
				'default'     => '1',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_minicart',
            array(
                'label'    => esc_html__( 'Minicart', 'irepair' ),
                'section'  => 'irepair_header_settings_elements',
                'settings' => 'irepair_header_minicart',
                'type'     => 'select',
                'choices'  => array(
                    '1'  => esc_html__( 'On', 'irepair' ),
                    '0' => esc_html__( 'Off', 'irepair' ),
                ),
                'priority'   => 20
            )
        );

		$wp_customize->add_setting( 'irepair_header_search' , array(
				'default'     => '1',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_search',
            array(
                'label'    => esc_html__( 'Search', 'irepair' ),
                'section'  => 'irepair_header_settings_elements',
                'settings' => 'irepair_header_search',
                'type'     => 'select',
                'choices'  => array(
                    '1'  => esc_html__( 'On', 'irepair' ),
                    '0' => esc_html__( 'Off', 'irepair' ),
                ),
                'priority'   => 30
            )
        );

		$wp_customize->add_setting( 'irepair_header_socials' , array(
				'default'     => '1',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
            'irepair_header_socials',
            array(
                'label'    => esc_html__( 'Socials', 'irepair' ),
                'section'  => 'irepair_header_settings_elements',
                'settings' => 'irepair_header_socials',
                'type'     => 'select',
                'choices'  => array(
                    '1'  => esc_html__( 'On', 'irepair' ),
                    '0' => esc_html__( 'Off', 'irepair' ),
                ),
                'priority'   => 40
            )
        );

		$wp_customize->add_setting( 'irepair_header_button' , array(
				'default'     => '0',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
				'irepair_header_button',
				array(
						'label'    => esc_html__( 'Button', 'irepair' ),
						'section'  => 'irepair_header_settings_elements',
						'settings' => 'irepair_header_button',
						'type'     => 'select',
						'choices'  => array(
								'1'  => esc_html__( 'On', 'irepair' ),
								'0' => esc_html__( 'Off', 'irepair' ),
						),
						'priority'   => 50
				)
		);



        /// HEADER INFO ///

		$wp_customize->add_section( 'irepair_header_settings_info' , array(
		    'title'      => esc_html__( 'Info Texts', 'irepair' ),
		    'priority'   => 25,
			'panel' => 'irepair_header_panel'
		) );


		$wp_customize->add_setting( 'irepair_header_phone' , array(
				'default'     => '',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_phone',
			array(
				'label'    => esc_html__( 'Phone', 'irepair' ),
				'section'  => 'irepair_header_settings_info',
				'settings' => 'irepair_header_phone',
				'type'     => 'text',
			)
		);
        
		$wp_customize->add_setting( 'irepair_header_email' , array(
				'default'     => '',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_email',
			array(
				'label'    => esc_html__( 'E-mail', 'irepair' ),
				'section'  => 'irepair_header_settings_info',
				'settings' => 'irepair_header_email',
				'type'     => 'text',
			)
		);
        
		$wp_customize->add_setting( 'irepair_header_button_text' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_button_text',
			array(
					'label'    => esc_html__( 'Button Text', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_button_text',
					'type'     => 'text',
			)
		);

		$wp_customize->add_setting( 'irepair_header_button_link' , array(
				'default'     => '',
				'transport'   => 'postMessage',
				'sanitize_callback' => 'esc_url'
		) );
		$wp_customize->add_control(
				'irepair_header_button_link',
				array(
						'label'    => esc_html__( 'Button Link', 'irepair' ),
						'section'  => 'irepair_header_settings_info',
						'settings' => 'irepair_header_button_link',
						'type'     => 'text',
				)
		);



		$wp_customize->add_setting( 'irepair_header_info_segment', array(
            'default' => 'info_1',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Segmented_Control(
                $wp_customize,
                'irepair_header_info_segment',
                array(
                    'label' => esc_html__( 'Info Sections', 'irepair' ),
                    'section' => 'irepair_header_settings_info',
                    'settings' => 'irepair_header_info_segment',
                    'choices'  => array(
                        'info_1' => esc_html__( 'Info 1', 'irepair' ),
                        'info_2' => esc_html__( 'Info 2', 'irepair' ),
                        'info_3' => esc_html__( 'Info 3', 'irepair' ),
                    ),
                    'align' => 'center',
                    'type' => 'tabs',
                    'hide_label' => 'hide',
                )
            )
        );

		$wp_customize->add_setting( 'irepair_header_info_icon_1' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_icon_1',
			array(
					'label'    => esc_html__( 'Icon 1', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_icon_1',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_title_1' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_title_1',
			array(
					'label'    => esc_html__( 'Title 1', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_title_1',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_1' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_1',
			array(
					'label'    => esc_html__( 'Info 1', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_1',
					'type'     => 'text',
			)
		);

		$wp_customize->add_setting( 'irepair_header_info_icon_2' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_icon_2',
			array(
					'label'    => esc_html__( 'Icon 2', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_icon_2',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_title_2' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_title_2',
			array(
					'label'    => esc_html__( 'Title 2', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_title_2',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_2' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_2',
			array(
					'label'    => esc_html__( 'Info 2', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_2',
					'type'     => 'text',
			)
		);

		$wp_customize->add_setting( 'irepair_header_info_icon_3' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_icon_3',
			array(
					'label'    => esc_html__( 'Icon 3', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_icon_3',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_title_3' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_title_3',
			array(
					'label'    => esc_html__( 'Title 3', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_title_3',
					'type'     => 'text',
			)
		);
		$wp_customize->add_setting( 'irepair_header_info_3' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'wp_kses_post'
		) );
		$wp_customize->add_control(
			'irepair_header_info_3',
			array(
					'label'    => esc_html__( 'Info 3', 'irepair' ),
					'section'  => 'irepair_header_settings_info',
					'settings' => 'irepair_header_info_3',
					'type'     => 'text',
			)
		);



        /// HEADER BACKGROUND ///

        $wp_customize->add_section( 'irepair_header_settings_bg_image' , array(
            'title'      => esc_html__( 'Background Image', 'irepair' ),
            'priority'   => 30,
            'panel' => 'irepair_header_panel'
        ) );


        $wp_customize->add_setting( 'irepair_tab_bg_image' , array(
            'default'     => '',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'irepair_tab_bg_image',
                array(
                    'label'      => esc_html__( 'Background Image', 'irepair' ),
                    'section'    => 'irepair_header_settings_bg_image',
                    'settings'   => 'irepair_tab_bg_image',
                    'priority'   => 10
                )
            )
        );

        $wp_customize->add_setting(	'irepair_tab_bg_image_horizontal_pos', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_bg_image_horizontal_pos',
                array(
                    'label' => esc_html__( 'Horizontal Position', 'irepair' ),
                    'section' => 'irepair_header_settings_bg_image',
                    'settings' => 'irepair_tab_bg_image_horizontal_pos',
                    'min' => 0,
                    'max' => 100,
                    'unit' => '%',
                    'priority'   => 12
                )
            )
        );

        $wp_customize->add_setting(	'irepair_tab_bg_image_vertical_pos', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_bg_image_vertical_pos',
                array(
                    'label' => esc_html__( 'Vertical Position', 'irepair' ),
                    'section' => 'irepair_header_settings_bg_image',
                    'settings' => 'irepair_tab_bg_image_vertical_pos',
                    'min' => 0,
                    'max' => 100,
                    'unit' => '%',
                    'priority'   => 13
                )
            )
        );

        $wp_customize->add_setting( 'irepair_tab_bg_image_fixed' , array(
            'default'     => '1',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_tab_bg_image_fixed',
            array(
                'label'    => esc_html__( 'Fixed Image', 'irepair' ),
                'section'  => 'irepair_header_settings_bg_image',
                'settings' => 'irepair_tab_bg_image_fixed',
                'type'     => 'select',
                'choices'  => array(
                    '0' => esc_html__( 'No', 'irepair' ),
                    '1' => esc_html__( 'Yes', 'irepair' ),
                ),
                'priority'   => 15
            )
        );

        $wp_customize->add_setting( 'irepair_tab_bg_color' , array(
            'default'     => get_option('irepair_default_tab_bg_color'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_tab_bg_color',
                array(
                    'label'      => esc_html__( 'Overlay Color', 'irepair' ),
                    'section'    => 'irepair_header_settings_bg_image',
                    'settings'   => 'irepair_tab_bg_color',
                    'priority'   => 20
                )
            )
        );

        $wp_customize->add_setting( 'irepair_tab_bg_color_gradient' , array(
            'default'     => get_option('irepair_default_tab_bg_color_gradient'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_tab_bg_color_gradient',
                array(
                    'label'      => esc_html__( 'Gradient Color', 'irepair' ),
                    'description'    => esc_html__( 'Set this color for gradient overlay', 'irepair'),
                    'section'    => 'irepair_header_settings_bg_image',
                    'settings'   => 'irepair_tab_bg_color_gradient',
                    'priority'   => 30
                )
            )
        );

        $wp_customize->add_setting( 'irepair_tab_gradient_direction' , array(
            'default'     => get_option('irepair_default_tab_gradient_direction'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_tab_gradient_direction',
            array(
                'label'    => esc_html__( 'Gradient Direction', 'irepair' ),
                'section'  => 'irepair_header_settings_bg_image',
                'settings' => 'irepair_tab_gradient_direction',
                'type'     => 'select',
                'choices'  => array(
                    'to right' => esc_html__( 'To Right ', 'irepair' ).html_entity_decode('&rarr;'),
                    'to left' => esc_html__( 'To Left ', 'irepair' ).html_entity_decode('&larr;'),
                    'to bottom' => esc_html__( 'To Bottom ', 'irepair' ).html_entity_decode('&darr;'),
                    'to top' => esc_html__( 'To Top ', 'irepair' ).html_entity_decode('&uarr;'),
                    'to bottom right' => esc_html__( 'To Bottom Right ', 'irepair' ).html_entity_decode('&#8600;'),
                    'to bottom left' => esc_html__( 'To Bottom Left ', 'irepair' ).html_entity_decode('&#8601;'),
                    'to top right' => esc_html__( 'To Top Right ', 'irepair' ).html_entity_decode('&#8599;'),
                    'to top left' => esc_html__( 'To Top Left ', 'irepair' ).html_entity_decode('&#8598;'),
                    //'angle' => esc_html__( 'Angle ', 'irepair' ).html_entity_decode('&#10227;'),
                ),
                'priority' => 40
            )
        );

        $wp_customize->add_setting( 'irepair_tab_bg_opacity' , array(
            'default'     => get_option('irepair_default_tab_bg_opacity'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_bg_opacity',
                array(
                    'label' => esc_html__( 'Overlay Opacity', 'irepair' ),
                    'section' => 'irepair_header_settings_bg_image',
                    'settings' => 'irepair_tab_bg_opacity',
                    'min' => 0,
                    'max' => 100,
                    'unit' => '%',
                    'priority' => 45
                )
            )
        );




        /// TITLE & BREADCRUMBS ///

        $wp_customize->add_section( 'irepair_header_settings_tab' , array(
            'title'      => esc_html__( 'Title & Breadcrumbs', 'irepair' ),
            'priority'   => 35,
            'panel' => 'irepair_header_panel'
        ) );


        $wp_customize->add_setting( 'irepair_tab_tone' , array(
            'default'     => '',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_tab_tone',
            array(
                'label'    => esc_html__( 'Text Tone', 'irepair' ),
                'section'  => 'irepair_header_settings_tab',
                'settings' => 'irepair_tab_tone',
                'type'     => 'select',
                'choices'  => array(
                    '' => esc_html__( 'Light', 'irepair' ),
                    'pix-tab-tone-dark' => esc_html__( 'Dark', 'irepair' ),
                ),
                'priority'   => 10
            )
        );


        $wp_customize->add_setting( 'irepair_tab_title_position' , array(
            'default'     => 'left',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_tab_title_position',
            array(
                'label'    => esc_html__( 'Page Title Position', 'irepair' ),
                'section'  => 'irepair_header_settings_tab',
                'settings' => 'irepair_tab_title_position',
                'type'     => 'select',
                'choices'  => array(
                    '' => esc_html__( 'Center', 'irepair' ),
                    'left' => esc_html__( 'Left', 'irepair' ),
                    'right' => esc_html__( 'Right', 'irepair' ),
                    'hide' => esc_html__( 'Hide', 'irepair' ),
                ),
                'priority'   => 50
            )
        );

        $wp_customize->add_setting( 'irepair_tab_breadcrumbs_position' , array(
            'default'     => 'right',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_tab_breadcrumbs_position',
            array(
                'label'    => esc_html__( 'Breadcrumbs Position', 'irepair' ),
                'section'  => 'irepair_header_settings_tab',
                'settings' => 'irepair_tab_breadcrumbs_position',
                'type'     => 'select',
                'choices'  => array(
                    '' => esc_html__( 'Center', 'irepair' ),
                    'left' => esc_html__( 'Left', 'irepair' ),
                    'right' => esc_html__( 'Right', 'irepair' ),
                    'hide' => esc_html__( 'Hide', 'irepair' ),
                ),
                'priority'   => 60
            )
        );

        $wp_customize->add_setting(	'irepair_tab_padding_top', array(
            'default' => get_option('irepair_default_tab_padding_top'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_padding_top',
                array(
                    'label' => esc_html__( 'Padding Top', 'irepair' ),
                    'section' => 'irepair_header_settings_tab',
                    'settings' => 'irepair_tab_padding_top',
                    'min' => 0,
                    'max' => 500,
                    'unit' => 'px',
                    'priority'   => 70
                )
            )
        );

        $wp_customize->add_setting(	'irepair_tab_padding_bottom', array(
            'default' => get_option('irepair_default_tab_padding_bottom'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_padding_bottom',
                array(
                    'label' => esc_html__( 'Padding Bottom', 'irepair' ),
                    'section' => 'irepair_header_settings_tab',
                    'settings' => 'irepair_tab_padding_bottom',
                    'min' => 0,
                    'max' => 500,
                    'unit' => 'px',
                    'priority'   => 80
                )
            )
        );

        $wp_customize->add_setting(	'irepair_tab_margin_bottom', array(
            'default' => get_option('irepair_default_tab_margin_bottom'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_tab_margin_bottom',
                array(
                    'label' => esc_html__( 'Margin Bottom', 'irepair' ),
                    'section' => 'irepair_header_settings_tab',
                    'settings' => 'irepair_tab_margin_bottom',
                    'min' => 0,
                    'max' => 200,
                    'unit' => 'px',
                    'priority'   => 90
                )
            )
        );

		
	}
		
?>