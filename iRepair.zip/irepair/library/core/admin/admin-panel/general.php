<?php 
	
	function irepair_customize_general_tab($wp_customize, $theme_name){

        $wp_customize->add_panel('irepair_general_panel',  array(
                'title' => esc_html__( 'General Settings', 'irepair' ),
                'priority' => 25,
            )
        );


        $wp_customize->add_section( 'irepair_general_settings' , array(
            'title'      => esc_html__( 'Logo', 'irepair' ),
            'priority'   => 15,
            'panel' => 'irepair_general_panel'
        ) );
		
		
		/* logo image */ 
		
		$wp_customize->add_setting( 'irepair_general_settings_logo' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
	        new WP_Customize_Image_Control(
	            $wp_customize,
	            'irepair_general_settings_logo',
				array(
				   'label'      => esc_html__( 'Image', 'irepair' ),
				   'section'    => 'irepair_general_settings',
				   'settings'   => 'irepair_general_settings_logo',
				)
	       )
	    );

		$wp_customize->add_setting(	'irepair_general_settings_logo_width', array(
            'default' => get_option('irepair_default_logo_width'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_general_settings_logo_width',
                array(
                    'label' => esc_html__( 'Max Width', 'irepair' ),
                    'description'=> esc_html__( 'Retina Logo should be 2x large than max width', 'irepair' ),
                    'section' => 'irepair_general_settings',
                    'settings' => 'irepair_general_settings_logo_width',
                    'min' => 0,
                    'max' => 300,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting(	'irepair_general_settings_logo_height', array(
            'default' => get_option('irepair_default_logo_height'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_general_settings_logo_height',
                array(
                    'label' => esc_html__( 'Min Height', 'irepair' ),
                    'description'=> esc_html__( 'Header Menu height', 'irepair' ),
                    'section' => 'irepair_general_settings',
                    'settings' => 'irepair_general_settings_logo_height',
                    'min' => 75,
                    'max' => 200,
                    'unit'=> 'px',
                )
            )
        );

		$wp_customize->add_setting( 'irepair_general_settings_logo_text' , array(
		    'default'     => '',
		    'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
			'irepair_general_settings_logo_text',
			array(
				'label'    => esc_html__( 'Logo Text', 'irepair' ),
				'section'  => 'irepair_general_settings',
				'settings' => 'irepair_general_settings_logo_text',
				'type'     => 'text',
			)
		);

		
		
		
        /// COLOR SETTINGS ///

        $wp_customize->add_section( 'irepair_style_settings' , array(
            'title'      => esc_html__( 'Colors', 'irepair' ),
            'priority'   => 20,
            'panel' => 'irepair_general_panel'
        ) );


        $wp_customize->add_setting(
            'irepair_style_settings_main_color',
            array(
                'default' => get_option('irepair_default_main_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_style_settings_main_color',
                array(
                    'label' => esc_html__( 'Main', 'irepair' ),
                    'section' => 'irepair_style_settings',
                    'settings' => 'irepair_style_settings_main_color',
                )
            )
        );

        $wp_customize->add_setting(
            'irepair_style_settings_gradient_color',
            array(
                'default' => get_option('irepair_default_gradient_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_style_settings_gradient_color',
                array(
                    'label' => esc_html__( 'Gradient', 'irepair' ),
                    'section' => 'irepair_style_settings',
                    'settings' => 'irepair_style_settings_gradient_color',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_gradient_direction' , array(
            'default'     => get_option('irepair_default_gradient_direction'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_gradient_direction',
            array(
                'label'    => esc_html__( 'Gradient Direction', 'irepair' ),
                'section'  => 'irepair_style_settings',
                'settings' => 'irepair_gradient_direction',
                'type'     => 'select',
                'choices'  => array(
                    'to right' => esc_html__( 'To Right ', 'irepair' ).html_entity_decode('&rarr;'),
                    'to left' => esc_html__( 'To Left ', 'irepair' ).html_entity_decode('&larr;'),
                    'to bottom' => esc_html__( 'To Bottom ', 'irepair' ).html_entity_decode('&darr;'),
                    'to top' => esc_html__( 'To Top ', 'irepair' ).html_entity_decode('&uarr;'),
                    'to bottom right' => esc_html__( 'To Bottom Right ', 'irepair' ).html_entity_decode('&#8600;'),
                    'to bottom left' => esc_html__( 'To Bottom Left ', 'irepair' ).html_entity_decode('&#8601;'),
                    'to top right' => esc_html__( 'To Top Right ', 'irepair' ).html_entity_decode('&#8599;'),
                    'to top left' => esc_html__( 'To Top Left ', 'irepair' ).html_entity_decode('&#8598;'),
                    //'angle' => esc_html__( 'Angle ', 'irepair' ).html_entity_decode('&#10227;'),
                ),
            )
        );

        $wp_customize->add_setting(
            'irepair_style_settings_additional_color',
            array(
                'default' => get_option('irepair_default_additional_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_style_settings_additional_color',
                array(
                    'label' => esc_html__( 'Additional', 'irepair' ),
                    'section' => 'irepair_style_settings',
                    'settings' => 'irepair_style_settings_additional_color',
                )
            )
        );








        /// FONT SETTINGS ///

        $wp_customize->add_section( 'irepair_style_font_settings' , array(
            'title'      => esc_html__( 'Fonts', 'irepair' ),
            'priority'   => 30,
            'panel' => 'irepair_general_panel',
        ) );

        $wp_customize->add_setting( 'irepair_font_api' , array(
            'default'     => '',
            'transport'   => 'refresh',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_font_api',
            array(
                'label' => esc_html__( 'Google Font Api Key', 'irepair' ),
                'description' => wp_kses_post(__('<a href="https://developers.google.com/fonts/docs/developer_api" target="_blank">Get Api Key</a>', 'irepair')),
                'type' => 'text',
                'section' => 'irepair_style_font_settings',
                'settings' => 'irepair_font_api',
            )
        );

        $wp_customize->add_setting( 'irepair_fonts_loader' , array(
            'default'     => get_option('irepair_default_fonts'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Fonts_Loader_Control(
                $wp_customize,
                'irepair_fonts_loader',
                array(
                    'label' => esc_html__( 'Fonts Loader', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_fonts_loader',
                )
            )
        );



        $wp_customize->add_setting( 'irepair_fonts_use_segment', array(
            'default' => 'text',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Segmented_Control(
                $wp_customize,
                'irepair_fonts_use_segment',
                array(
                    'label' => esc_html__( 'Fonts & Titles', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_fonts_use_segment',
                    'choices'  => array(
                        'text' => esc_html__( 'Text', 'irepair' ),
                        'title' => esc_html__( 'Title', 'irepair' ),
                        'subtitle' => esc_html__( 'Subtitle', 'irepair' ),
                        'link' => esc_html__( 'H Link', 'irepair' ),
                        'button' => esc_html__( 'Button', 'irepair' ),
                    ),
                    'align' => 'center',
                    'type' => 'tabs',
                    'hide_label' => 'hide',
                )
            )
        );



        $wp_customize->add_setting( 'irepair_font' , array(
            'default'     => get_option('irepair_default_font'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Control(
                $wp_customize,
                'irepair_font',
                array(
                    'label' => esc_html__( 'Text Font', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_font',
                    'weight_id' => 'irepair_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_font_weight' , array(
            'default'     => get_option('irepair_default_font_weight'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Weight_Control(
                $wp_customize,
                'irepair_font_weight',
                array(
                    'label' => esc_html__( 'Text Weight', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_font_weight',
                    'weight_id' => 'irepair_font_weight',
                )
            )
        );

        $wp_customize->add_setting(	'irepair_font_size', array(
            'default' => '12',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_font_size',
                array(
                    'label' => esc_html__( 'Text Size', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_font_size',
                    'min' => 10,
                    'max' => 20,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting(
            'irepair_font_color',
            array(
                'default' => get_option('irepair_default_font_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_font_color',
                array(
                    'label' => esc_html__( 'Text Color', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_font_color',
                )
            )
        );



        $wp_customize->add_setting( 'irepair_title_font' , array(
            'default'     => get_option('irepair_default_title'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Control(
                $wp_customize,
                'irepair_title_font',
                array(
                    'label' => esc_html__( 'Title Font', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_title_font',
                    'weight_id' => 'irepair_title_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_title_font_weight' , array(
            'default'     => get_option('irepair_default_title_weight'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Weight_Control(
                $wp_customize,
                'irepair_title_font_weight',
                array(
                    'label' => esc_html__( 'Title Weight', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_title_font_weight',
                    'weight_id' => 'irepair_title_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_title_font_size', array(
            'default' => '28',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_title_font_size',
                array(
                    'label' => esc_html__( 'Title Size', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_title_font_size',
                    'min' => 10,
                    'max' => 70,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting(
            'irepair_title_font_color',
            array(
                'default' => get_option('irepair_default_title_font_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_title_font_color',
                array(
                    'label' => esc_html__( 'Title Color', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_title_font_color',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_title_font_style' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            'irepair_title_font_style',
            array(
                'label'    => esc_html__( 'Title Style', 'irepair' ),
                'section'  => 'irepair_style_font_settings',
                'settings' => 'irepair_title_font_style',
                'type'     => 'select',
                'choices'  => array(
                    'normal' => esc_html__( 'Normal', 'irepair' ),
                    'italic' => esc_html__( 'Italic', 'irepair' ),
                    'oblique' => esc_html__( 'Oblique', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_title_letter_spacing', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_title_letter_spacing',
                array(
                    'label' => esc_html__( 'Title Letter Spacing', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_title_letter_spacing',
                    'min' => 0,
                    'max' => 30,
                    'unit'=> 'px',
                    'step'=> '0.25',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_subtitle_font' , array(
            'default'     => get_option('irepair_default_subtitle'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Control(
                $wp_customize,
                'irepair_subtitle_font',
                array(
                    'label' => esc_html__( 'Subtitle Font', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_subtitle_font',
                    'weight_id' => 'irepair_subtitle_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_subtitle_font_weight' , array(
            'default'     => get_option('irepair_default_subtitle_weight'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Weight_Control(
                $wp_customize,
                'irepair_subtitle_font_weight',
                array(
                    'label' => esc_html__( 'Subtitle Weight', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_subtitle_font_weight',
                    'weight_id' => 'irepair_subtitle_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_subtitle_font_size', array(
            'default' => '20',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_subtitle_font_size',
                array(
                    'label' => esc_html__( 'Subtitle Size', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_subtitle_font_size',
                    'min' => 10,
                    'max' => 70,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting(
            'irepair_subtitle_font_color',
            array(
                'default' => get_option('irepair_default_subtitle_font_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_subtitle_font_color',
                array(
                    'label' => esc_html__( 'Subtitle Color', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_subtitle_font_color',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_subtitle_font_style' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            'irepair_subtitle_font_style',
            array(
                'label'    => esc_html__( 'Subtitle Style', 'irepair' ),
                'section'  => 'irepair_style_font_settings',
                'settings' => 'irepair_subtitle_font_style',
                'type'     => 'select',
                'choices'  => array(
                    'normal' => esc_html__( 'Normal', 'irepair' ),
                    'italic' => esc_html__( 'Italic', 'irepair' ),
                    'oblique' => esc_html__( 'Oblique', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_subtitle_letter_spacing', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_subtitle_letter_spacing',
                array(
                    'label' => esc_html__( 'Subtitle Letter Spacing', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_subtitle_letter_spacing',
                    'min' => 0,
                    'max' => 30,
                    'unit'=> 'px',
                    'step'=> '0.25',
                )
            )
        );



        $wp_customize->add_setting( 'irepair_link_font' , array(
            'default'     => get_option('irepair_default_font'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Control(
                $wp_customize,
                'irepair_link_font',
                array(
                    'label' => esc_html__( 'H Link Font', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_link_font',
                    'weight_id' => 'irepair_link_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_link_font_weight' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Weight_Control(
                $wp_customize,
                'irepair_link_font_weight',
                array(
                    'label' => esc_html__( 'H Link Weight', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_link_font_weight',
                    'weight_id' => 'irepair_link_font_weight',
                )
            )
        );

        $wp_customize->add_setting(	'irepair_link_font_size', array(
            'default' => '10',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_link_font_size',
                array(
                    'label' => esc_html__( 'H Link Size', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_link_font_size',
                    'min' => 10,
                    'max' => 30,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_link_font_style' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            'irepair_link_font_style',
            array(
                'label'    => esc_html__( 'H Link Style', 'irepair' ),
                'section'  => 'irepair_style_font_settings',
                'settings' => 'irepair_link_font_style',
                'type'     => 'select',
                'choices'  => array(
                    'normal' => esc_html__( 'Normal', 'irepair' ),
                    'italic' => esc_html__( 'Italic', 'irepair' ),
                    'oblique' => esc_html__( 'Oblique', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting(
            'irepair_link_font_color',
            array(
                'default' => get_option('irepair_default_link_font_color'),
                'transport'   => 'postMessage',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_link_font_color',
                array(
                    'label' => esc_html__( 'H Link Color', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_link_font_color',
                )
            )
        );



        $wp_customize->add_setting( 'irepair_buttons_font' , array(
            'default'     => get_option('irepair_default_font'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'irepair_sanitize_text'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Control(
                $wp_customize,
                'irepair_buttons_font',
                array(
                    'label' => esc_html__( 'Button Font', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_buttons_font',
                    'weight_id' => 'irepair_buttons_font_weight',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_buttons_font_weight' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            new iRepair_Google_Font_Weight_Control(
                $wp_customize,
                'irepair_buttons_font_weight',
                array(
                    'label' => esc_html__( 'Button Font Weight', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_buttons_font_weight',
                    'weight_id' => 'irepair_buttons_font_weight',
                )
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_font_size', array(
            'default' => '12',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_font_size',
                array(
                    'label' => esc_html__( 'Button Font Size', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_buttons_font_size',
                    'min' => 10,
                    'max' => 30,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting( 'irepair_buttons_font_style' , array(
            'default'     => 'normal',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            'irepair_buttons_font_style',
            array(
                'label'    => esc_html__( 'Button Font Style', 'irepair' ),
                'section'  => 'irepair_style_font_settings',
                'settings' => 'irepair_buttons_font_style',
                'type'     => 'select',
                'choices'  => array(
                    'normal' => esc_html__( 'Normal', 'irepair' ),
                    'italic' => esc_html__( 'Italic', 'irepair' ),
                    'oblique' => esc_html__( 'Oblique', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_buttons_text_transform' , array(
            'default'     => 'none',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field'
        ) );
        $wp_customize->add_control(
            'irepair_buttons_text_transform',
            array(
                'label'    => esc_html__( 'Button Text Transform', 'irepair' ),
                'section'  => 'irepair_style_font_settings',
                'settings' => 'irepair_buttons_text_transform',
                'type'     => 'select',
                'choices'  => array(
                    'none' => esc_html__( 'None', 'irepair' ),
                    'uppercase' => esc_html__( 'UPPERCASE', 'irepair' ),
                    'capitalize' => esc_html__( 'Capitalize', 'irepair' ),
                    'lowercase' => esc_html__( 'lowercase', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_buttons_letter_spacing', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_letter_spacing',
                array(
                    'label' => esc_html__( 'Button Letter Spacing', 'irepair' ),
                    'section' => 'irepair_style_font_settings',
                    'settings' => 'irepair_buttons_letter_spacing',
                    'min' => 0,
                    'max' => 10,
                    'unit'=> 'px',
                    'step'=> '0.1',
                )
            )
        );








        /// DECOR SETTINGS ///

        $wp_customize->add_section( 'irepair_decor_settings' , array(
            'title'      => esc_html__( 'Decor', 'irepair' ),
            'priority'   => 35,
            'panel' => 'irepair_general_panel',
        ) );

        $wp_customize->add_setting( 'irepair_decor_show' , array(
            'default'     => get_option('irepair_default_decor'),
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_decor_show',
            array(
                'label'    => esc_html__( 'Show Decor', 'irepair' ),
                'section'  => 'irepair_decor_settings',
                'settings' => 'irepair_decor_show',
                'type'     => 'select',
                'choices'  => array(
                    '1' => esc_html__( 'Yes', 'irepair' ),
                    '0' => esc_html__( 'No', 'irepair' ),
                ),
            )
        );

        $wp_customize->add_setting( 'irepair_decor_img' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
	        new WP_Customize_Image_Control(
	            $wp_customize,
	            'irepair_decor_img',
				array(
				   'label'      => esc_html__( 'Decor', 'irepair' ),
				   'section'    => 'irepair_decor_settings',
				   'settings'   => 'irepair_decor_img',
				)
	       )
	    );

        $wp_customize->add_setting(	'irepair_decor_width', array(
            'default' => '40',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_decor_width',
                array(
                    'label' => esc_html__( 'Width', 'irepair' ),
                    'section' => 'irepair_decor_settings',
                    'settings' => 'irepair_decor_width',
                    'min' => 0,
                    'max' => 100,
                    'unit'=> 'px',
                )
            )
        );

        $wp_customize->add_setting(	'irepair_decor_height', array(
            'default' => '10',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_decor_height',
                array(
                    'label' => esc_html__( 'Height', 'irepair' ),
                    'section' => 'irepair_decor_settings',
                    'settings' => 'irepair_decor_height',
                    'min' => 0,
                    'max' => 50,
                    'unit'=> 'px',
                )
            )
        );





        /// BUTTONS SETTINGS ///

        $wp_customize->add_section( 'irepair_buttons_settings' , array(
            'title'      => esc_html__( 'Buttons', 'irepair' ),
            'priority'   => 40,
            'panel' => 'irepair_general_panel',
        ) );

        $wp_customize->add_setting( 'irepair_buttons_shape' , array(
		    'default'     => 'pix-square',
		    'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
			'irepair_buttons_shape',
			array(
				'label'    => esc_html__( 'Shape', 'irepair' ),
				'section'  => 'irepair_buttons_settings',
				'settings' => 'irepair_buttons_shape',
				'type'     => 'select',
				'choices'  => array(
					'pix-square'  => esc_html__( 'Square', 'irepair' ),
					'pix-rounded' => esc_html__( 'Rounded', 'irepair' ),
					'pix-round' => esc_html__( 'Round', 'irepair' ),
				),
				'priority'   => 10
			)
		);

		$wp_customize->add_setting(	'irepair_buttons_border', array(
            'default' => '2',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_border',
                array(
                    'label' => esc_html__( 'Border Width', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_border',
                    'min' => 0,
                    'max' => 5,
                    'unit'=> 'px',
                    'priority'   => 20
                )
            )
        );
        
        $wp_customize->add_setting( 'irepair_buttons_shadow' , array(
            'default'     => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_buttons_shadow',
            array(
                'label'    => esc_html__( 'Shadow', 'irepair' ),
                'section'  => 'irepair_buttons_settings',
                'settings' => 'irepair_buttons_shadow',
                'type'     => 'select',
                'choices'  => array(
                    '1' => esc_html__( 'Yes', 'irepair' ),
                    '0' => esc_html__( 'No', 'irepair' ),
                ),
                'priority'   => 70
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_shadow_h', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_shadow_h',
                array(
                    'label' => esc_html__( 'Horizontal Position', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_h',
                    'min' => -100,
                    'max' => 100,
                    'unit'=> 'px',
                    'priority'   => 80
                )
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_shadow_v', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_shadow_v',
                array(
                    'label' => esc_html__( 'Vertical Position', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_v',
                    'min' => -100,
                    'max' => 100,
                    'unit'=> 'px',
                    'priority'   => 90
                )
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_shadow_blur', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_shadow_blur',
                array(
                    'label' => esc_html__( 'Blur', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_blur',
                    'min' => 0,
                    'max' => 100,
                    'unit'=> 'px',
                    'priority'   => 100
                )
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_shadow_spread', array(
            'default' => '0',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_shadow_spread',
                array(
                    'label' => esc_html__( 'Spread', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_spread',
                    'min' => -100,
                    'max' => 100,
                    'unit'=> 'px',
                    'priority'   => 110
                )
            )
        );

        $wp_customize->add_setting(	'irepair_buttons_shadow_color', array(
            'default' => '#333',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'sanitize_hex_color',
        ) );
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'irepair_buttons_shadow_color',
                array(
                    'label' => esc_html__( 'Color', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_color',
                    'priority'   => 120
                )
            )
        );

        $wp_customize->add_setting( 'irepair_buttons_shadow_opacity' , array(
            'default'     => '100',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            new iRepair_Slider_Single_Control(
                $wp_customize,
                'irepair_buttons_shadow_opacity',
                array(
                    'label' => esc_html__( 'Opacity', 'irepair' ),
                    'section' => 'irepair_buttons_settings',
                    'settings' => 'irepair_buttons_shadow_opacity',
                    'min' => 0,
                    'max' => 100,
                    'unit'=> '%',
                    'priority'   => 130
                )
            )
        );






        /// OTHER SETTINGS ///

        $wp_customize->add_section( 'irepair_other_settings' , array(
            'title'      => esc_html__( 'Other', 'irepair' ),
            'priority'   => 100,
            'panel' => 'irepair_general_panel',
        ) );

        $wp_customize->add_setting( 'irepair_theme_boxes_shape' , array(
		    'default'     => 'pix-rounded',
		    'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
			'irepair_theme_boxes_shape',
			array(
				'label'    => esc_html__( 'Boxes Shape', 'irepair' ),
				'section'  => 'irepair_other_settings',
				'settings' => 'irepair_theme_boxes_shape',
				'type'     => 'select',
				'choices'  => array(
					'pix-square'  => esc_html__( 'Square', 'irepair' ),
					'pix-rounded' => esc_html__( 'Rounded', 'irepair' ),
					'pix-round' => esc_html__( 'Round', 'irepair' ),
				),
			)
		);

        $wp_customize->add_setting( 'irepair_general_settings_loader' , array(
		    'default'     => 'useall',
		    'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
			'irepair_general_settings_loader',
			array(
				'label'    => esc_html__( 'Page Loader', 'irepair' ),
				'section'  => 'irepair_other_settings',
				'settings' => 'irepair_general_settings_loader',
				'type'     => 'select',
				'choices'  => array(
					'off'  => esc_html__( 'Off', 'irepair' ),
					'usemain' => esc_html__( 'Use on main', 'irepair' ),
					'useall' => esc_html__( 'Use on all pages', 'irepair' ),
				),
			)
		);

		$wp_customize->add_setting( 'irepair_loader_img' , array(
			'default'     => '',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		$wp_customize->add_control(
	        new WP_Customize_Image_Control(
	            $wp_customize,
	            'irepair_loader_img',
				array(
				   'label'      => esc_html__( 'Loader Image', 'irepair' ),
				   'section'    => 'irepair_other_settings',
				   'settings'   => 'irepair_loader_img',
				)
	       )
	    );

        $wp_customize->add_setting( 'irepair_map_api' , array(
            'default'     => '',
            'transport'   => 'postMessage',
            'sanitize_callback' => 'esc_attr'
        ) );
        $wp_customize->add_control(
            'irepair_map_api',
            array(
                'label' => esc_html__( 'Google Map Api Key', 'irepair' ),
                'description' => wp_kses_post(__('<a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Get Api Key</a>', 'irepair')),
                'type' => 'text',
                'section' => 'irepair_other_settings',
                'settings' => 'irepair_map_api',
            )
        );

		
		
	}
	
	