<?php 
	
	function irepair_customize_footer_tab($wp_customize, $theme_name){

		$wp_customize->add_section( 'irepair_footer_settings' , array(
		    'title'      => esc_html__( 'Footer', 'irepair' ),
		    'priority'   => 75,
		) );


		$staticBlocks = irepair_get_staticblock_option_array();

		$wp_customize->add_setting( 'irepair_footer_block_top' , array(
			'default'     => '0',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'esc_html'
		) );
		$wp_customize->add_control(
			'irepair_footer_block_top',
			array(
				'label'    => esc_html__( 'Top Footer Block', 'irepair' ),
				'section'  => 'irepair_footer_settings',
				'settings' => 'irepair_footer_block_top',
				'type'     => 'select',
				'choices'  => $staticBlocks,
				'priority' => 10
			)
		);

		$wp_customize->add_setting( 'irepair_footer_block' , array(
			'default'     => '0',
			'transport'   => 'postMessage',
			'sanitize_callback' => 'esc_html'
		) );
		$wp_customize->add_control(
			'irepair_footer_block',
			array(
				'label'    => esc_html__( 'Bottom Footer Block', 'irepair' ),
				'section'  => 'irepair_footer_settings',
				'settings' => 'irepair_footer_block',
				'type'     => 'select',
				'choices'  => $staticBlocks,
				'priority' => 20
			)
		);

		$wp_customize->add_setting( 'irepair_footer_socials' , array(
            'default'     => '1',
            'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_html'
        ) );

		$wp_customize->add_control(
            'irepair_footer_socials',
            array(
                'label'    => esc_html__( 'Show Footer Socials', 'irepair' ),
                'description' => esc_html__( 'Display, if Top and Bottom Footer Blocks are not selected.', 'irepair' ),
                'section'  => 'irepair_footer_settings',
                'settings' => 'irepair_footer_socials',
                'type'     => 'select',
                'choices'  => array(
                    '1'  => esc_html__( 'On', 'irepair' ),
                    '0' => esc_html__( 'Off', 'irepair' ),
                ),
                'priority'   => 30
            )
        );

        $wp_customize->add_setting( 'irepair_footer_copyright' , array(
            'default'     => esc_html__( 'Copyright 2018. Designed by PixTheme', 'irepair' ),
            'transport'   => 'postMessage',
		    'sanitize_callback' => 'esc_html'
        ) );

        $wp_customize->add_control(
            'irepair_footer_copyright',
            array(
                'label'    => esc_html__( 'Footer Copyright Text', 'irepair' ),
                'description' => esc_html__( 'Display, if Top and Bottom Footer Blocks are not selected.', 'irepair' ),
                'section'  => 'irepair_footer_settings',
                'settings' => 'irepair_footer_copyright',
                'type'     => 'textarea',
                'priority'   => 40
            )
        );


	}
		
?>