<?php
	/**  Core_Global  **/

	get_template_part( 'library/core/global/functions');
	get_template_part( 'library/core/global/sidebars');

?>