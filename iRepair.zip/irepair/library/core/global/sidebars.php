<?php 


function irepair_init_sidebars(){
	if ( function_exists('register_sidebar') ){
	
		register_sidebar(array(
			'name' => esc_html__('WP Default Sidebar', 'irepair'),
			'id'	=> 'sidebar-1',
			'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3><div class="sep-element"></div>',
		));
	
		register_sidebar(array(
			'name' => esc_html__('Blog Sidebar', 'irepair'),
			'id' => 'global-sidebar-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));

		register_sidebar(array(
			'name' => esc_html__('Portfolio Sidebar', 'irepair'),
			'id' => 'portfolio-sidebar-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));

		register_sidebar(array(
			'name' => esc_html__('Services Sidebar', 'irepair'),
			'id' => 'services-sidebar-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));

		register_sidebar(array(
			'name' => esc_html__('Shop sidebar', 'irepair'),
			'id'	=> 'shop-sidebar-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));

		register_sidebar(array(
			'name' => esc_html__('Product sidebar', 'irepair'),
			'id'	=> 'product-sidebar-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));

		register_sidebar(array(
			'name' => esc_html__('Custom Area', 'irepair'),
			'id'	=> 'custom-area-1',
            'before_widget' => '<div id="%1$s" class="%2$s side-menu__item widget">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3><div class="sep-element"></div>',
		));
		
		
		
	}
}


add_action('widgets_init','irepair_init_sidebars');