<?php

    /* Define library path */

    /* Load CORE main file */
    require_once(get_template_directory() . '/library/core/index.php');

    /* Load THEME main file */
    require_once(get_template_directory() . '/library/theme/index.php');

    /* Load VC MAP files */
    require_once(get_template_directory() . '/vc_templates/vc_maps/index.php');

    /* Load Plugins */
    require_once(get_template_directory() . '/library/plugins.php');

?>