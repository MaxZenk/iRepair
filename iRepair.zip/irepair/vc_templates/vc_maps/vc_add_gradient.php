<?php

    $padding_attr = array(
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Padding Top', 'irepair' ),
            'param_name' => 'pix_padding_top',
            'value' => array(
                'default' => 'pix-padding-top-l',
                esc_html__( 'No Padding', 'irepair' ) => 'pix-top-no-padding',
                esc_html__( 'S', 'irepair' ) => 'pix-padding-top-s',
                esc_html__( 'M', 'irepair' ) => 'pix-padding-top-m',
                esc_html__( 'L', 'irepair' ) => 'pix-padding-top-l',
                esc_html__( 'XL', 'irepair' ) => 'pix-padding-top-xl',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Padding Bottom', 'irepair' ),
            'param_name' => 'pix_padding_bottom',
            'value' => array(
                'default' => 'pix-padding-bottom-l',
                esc_html__( 'No Padding', 'irepair' ) => 'pix-bottom-no-padding',
                esc_html__( 'S', 'irepair' ) => 'pix-padding-bottom-s',
                esc_html__( 'M', 'irepair' ) => 'pix-padding-bottom-m',
                esc_html__( 'L', 'irepair' ) => 'pix-padding-bottom-l',
                esc_html__( 'XL', 'irepair' ) => 'pix-padding-bottom-xl',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
    );

    $padding_no_attr = array(
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Padding Top', 'irepair' ),
            'param_name' => 'pix_padding_top',
            'value' => array(
                'default' => 'pix-top-no-padding',
                esc_html__( 'No Padding', 'irepair' ) => 'pix-top-no-padding',
                esc_html__( 'S', 'irepair' ) => 'pix-padding-top-s',
                esc_html__( 'M', 'irepair' ) => 'pix-padding-top-m',
                esc_html__( 'L', 'irepair' ) => 'pix-padding-top-l',
                esc_html__( 'XL', 'irepair' ) => 'pix-padding-top-xl',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Padding Bottom', 'irepair' ),
            'param_name' => 'pix_padding_bottom',
            'value' => array(
                'default' => 'pix-bottom-no-padding',
                esc_html__( 'No Padding', 'irepair' ) => 'pix-bottom-no-padding',
                esc_html__( 'S', 'irepair' ) => 'pix-padding-bottom-s',
                esc_html__( 'M', 'irepair' ) => 'pix-padding-bottom-m',
                esc_html__( 'L', 'irepair' ) => 'pix-padding-bottom-l',
                esc_html__( 'XL', 'irepair' ) => 'pix-padding-bottom-xl',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
    );

	$row_attr = array(
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Container Shape', 'irepair' ),
            'param_name' => 'radius',
            'value' => array(
                'default' => 'default',
                esc_html__( 'Square', 'irepair' ) => 'default',
                esc_html__( 'Rounded', 'irepair' ) => 'pix-rounded',
                esc_html__( 'Round', 'irepair' ) => 'pix-round',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Text Color', 'irepair' ),
            'param_name' => 'ptextcolor',
            'value' => array(
                'default' => 'Default',
                esc_html__( 'Default', 'irepair' ) => 'Default',
                esc_html__( 'Light', 'irepair' ) => 'White',
                esc_html__( 'Dark', 'irepair' ) => 'Black',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
		array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Fixed Background Image', 'irepair' ),
            'param_name' => 'bgstyle',
            'value' => 'off',
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Image', 'irepair' ),
            'param_name' => 'bgimage',
            'value' => '',
            'description' => esc_html__( 'Fixed background image', 'irepair' ),
            'dependency' => array(
                'element' => 'bgstyle',
                'value' => 'on',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),

    );

	$column_attr = array(
	    array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Not Stretch Content Alignment', 'irepair' ),
            'param_name' => 'pix_not_stretch_content',
            'value' => array(
                'default' => 'off',
                esc_html__( 'Off', 'irepair' ) => 'off',
                esc_html__( 'Left', 'irepair' ) => 'pix-col-content-left',
                esc_html__( 'Center', 'irepair' ) => 'pix-col-content-center',
                esc_html__( 'Right', 'irepair' ) => 'pix-col-content-right',
            ),
            'description' => esc_html__( 'If you don\'t want to stretch content in column with row setting \'Stretch row and content\'.', 'irepair' ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
        ),
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Text Color', 'irepair' ),
            'param_name' => 'ptextcolor',
            'value' => array(
                'default' => 'Default',
                esc_html__( 'Default', 'irepair' ) => 'Default',
                esc_html__( 'Light', 'irepair' ) => 'White',
                esc_html__( 'Dark', 'irepair' ) => 'Black',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
        ),
		array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Fixed Background Image', 'irepair' ),
            'param_name' => 'bgstyle',
            'value' => 'off',
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Image', 'irepair' ),
            'param_name' => 'bgimage',
            'value' => '',
            'description' => esc_html__( 'Fixed background image', 'irepair' ),
            'dependency' => array(
                'element' => 'bgstyle',
                'value' => 'on',
            ),
            'group' => esc_html__( 'PixAdvanced', 'irepair' ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
    );


    $gradient_attr = array(
		// Gradient
        array(
            'type' => 'param_group',
            'value' => '',
            'heading' => esc_html__( 'Gradient', 'irepair' ),
            'param_name' => 'gradient_colors',
            // Note params is mapped inside param-group:
            'params' => array(
                array(
                    'type' => 'colorpicker',
                    'value' => '',
                    'heading' => esc_html__( 'Color For Gradient', 'irepair' ),
                    'param_name' => 'gradient_color',
                )
            ),
		    'group' => esc_html__( 'Gradient', 'irepair' ),
        ),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Direction', 'irepair' ),
			'param_name' => 'gradient_direction',
			'value' => array(
				esc_html__( 'To Right ', 'irepair' ).html_entity_decode('&rarr;') => 'to right',
				esc_html__( 'To Left ', 'irepair' ).html_entity_decode('&larr;') => 'to left',
				esc_html__( 'To Bottom ', 'irepair' ).html_entity_decode('&darr;') => 'to bottom',
				esc_html__( 'To Top ', 'irepair' ).html_entity_decode('&uarr;') => 'to top',
				esc_html__( 'To Bottom Right ', 'irepair' ).html_entity_decode('&#8600;') => 'to bottom right',
				esc_html__( 'To Bottom Left ', 'irepair' ).html_entity_decode('&#8601;') => 'to bottom left',
				esc_html__( 'To Top Right ', 'irepair' ).html_entity_decode('&#8599;') => 'to top right',
				esc_html__( 'To Top Left ', 'irepair' ).html_entity_decode('&#8598;') => 'to top left',
				esc_html__( 'Angle ', 'irepair' ).html_entity_decode('&#10227;') => 'angle',
			),
			'description' => '',
			'group' => esc_html__( 'Gradient', 'irepair' ),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Angle Direction', 'irepair' ),
			'param_name' => 'gradient_angle',
			'value' => '90',
			'description' => esc_html__( 'Values -360 - 360', 'irepair' ),
			'dependency' => array(
				'element' => 'gradient_direction',
				'value' => 'angle',
			),
			'group' => esc_html__( 'Gradient', 'irepair' ),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Opacity', 'irepair' ),
			'param_name' => 'gradient_opacity',
			'value' => '1',
			'description' => esc_html__( 'Values 0.01 - 0.99', 'irepair' ),
			'group' => esc_html__( 'Gradient', 'irepair' ),
		),
        
	);


	$decor_attr = array(
        
        // Decors
        // Top Decor
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Show Top Decor', 'irepair' ),
            'param_name' => 'pdecor',
            'value' => 'off',
            'description' => esc_html__( 'Show decor at the top of the section.', 'irepair' ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Height', 'irepair' ),
            'param_name' => 'decor_height',
            'value' => '150',
            'description' => esc_html__( 'Values 0 - 300', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Top Decor Opacity', 'irepair' ),
            'param_name' => 'decor_opacity',
            'value' => '',
            'description' => esc_html__( 'Values 0.01 - 0.99', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Top Decor Points', 'irepair' ),
            'param_name' => 'decor_points_top',
            'value' => '',
            'description' => esc_html__( 'Example: 0,100 50,50 100,100', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),

        // Bottom Decor
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Show Bottom Decor', 'irepair' ),
            'param_name' => 'pdecor_bottom',
            'value' => 'off',
            'description' => esc_html__( "Show decor at the bottom of the section.", 'irepair' ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Height', 'irepair' ),
            'param_name' => 'decor_bottom_height',
            'value' => '150',
            'description' => esc_html__( 'Values 0 - 300', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor_bottom',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Bottom Decor Opacity', 'irepair' ),
            'param_name' => 'decor_bottom_opacity',
            'value' => '',
            'description' => esc_html__( 'Values 0.01 - 0.99', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor_bottom',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Bottom Decor Points', 'irepair' ),
            'param_name' => 'decor_points_bottom',
            'value' => '',
            'description' => esc_html__( 'Example: 0,100 50,50 100,100', 'irepair' ),
            'dependency' => array(
                'element' => 'pdecor_bottom',
                'value' => 'on',
            ),
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),

        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Overlay', 'irepair' ),
            'param_name' => 'poverlay',
            'value' => array(
                esc_html__( "Use", 'irepair' ) => 'pix-row-overlay',
                esc_html__( "None", 'irepair' ) => 'no-overlay',
            ),
            'description' => '',
            'group' => esc_html__( 'Decor', 'irepair' ),
        ),
	);

	vc_add_params( 'vc_row', array_merge($padding_attr, $row_attr, $gradient_attr) );
	vc_add_params( 'vc_row_inner', array_merge($padding_no_attr, $row_attr, $gradient_attr) );
	vc_add_params( 'vc_column', array_merge($padding_no_attr, $column_attr, $gradient_attr) );

?>