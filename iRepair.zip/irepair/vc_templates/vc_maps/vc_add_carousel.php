<?php

	$carousel = array(
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Carousel', 'irepair' ),
            'param_name' => 'carousel',
            'value' => 'on',
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'segmented_button',
            'heading' => esc_html__( 'Items per Page', 'irepair' ),
            'param_name' => 'carousel_items',
            'value' => array(
                'default' => 3,
                esc_html__( '1', 'irepair' ) => 1,
                esc_html__( '2', 'irepair' ) => 2,
                esc_html__( '3', 'irepair' ) => 3,
                esc_html__( '4', 'irepair' ) => 4,
                esc_html__( '5', 'irepair' ) => 5,
                esc_html__( '6', 'irepair' ) => 6,
                esc_html__( '7', 'irepair' ) => 7,
                esc_html__( '8', 'irepair' ) => 8,
                esc_html__( '9', 'irepair' ) => 9,
                esc_html__( '10', 'irepair' ) => 10,
            ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-8',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Pagination', 'irepair' ),
            'param_name' => 'carousel_dots',
            'value' => 'on',
            'description' => esc_html__( 'Pagination dots ...', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Navigation', 'irepair' ),
            'param_name' => 'carousel_nav',
            'value' => 'off',
            'description' => esc_html__( 'Navigation arrows < >', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Loop', 'irepair' ),
            'param_name' => 'carousel_loop',
            'value' => 'off',
            'description' => esc_html__( 'Infinity loop', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Margin', 'irepair' ),
            'param_name' => 'carousel_margin',
            'value' => '',
            'description' => esc_html__( 'margin-right(px) on item', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'on Tablet', 'irepair' ),
            'param_name' => 'carousel_margin_tablet',
            'value' => '',
            'description' => '',
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'on Mobile', 'irepair' ),
            'param_name' => 'carousel_margin_mobile',
            'value' => '',
            'description' => '',
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Padding', 'irepair' ),
            'param_name' => 'carousel_stagepadding',
            'value' => '',
            'description' => esc_html__( 'Padding left and right on stage', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'on Tablet', 'irepair' ),
            'param_name' => 'carousel_stagepadding_tablet',
            'value' => '',
            'description' => '',
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'on Mobile', 'irepair' ),
            'param_name' => 'carousel_stagepadding_mobile',
            'value' => '',
            'description' => '',
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'range_slider',
            'heading' => esc_html__( 'Speed', 'irepair' ),
            'param_name' => 'carousel_speed',
            'value' => array(
                'default' => '1000',
                'min' => '0',
                'max' => '10000',
                'step' => '100',
                'unit' => 'ms',
            ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Autoplay', 'irepair' ),
            'param_name' => 'carousel_autoplay',
            'value' => 'off',
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'range_slider',
            'heading' => esc_html__( 'Autoplay Speed', 'irepair' ),
            'param_name' => 'carousel_autoplaySpeed',
            'value' => array(
                'default' => '1000',
                'min' => '0',
                'max' => '10000',
                'step' => '100',
                'unit' => 'ms',
            ),
            'dependency' => array(
                'element' => 'carousel_autoplay',
                'value' => 'on'
            ),
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
        array(
            'type' => 'switch_button',
            'heading' => esc_html__( 'Animate Next Slide', 'irepair' ),
            'param_name' => 'carousel_animation',
            'value' => 'off',
            'description' => esc_html__( 'FadeInUp animate', 'irepair' ),
            'dependency' => array(
                'element' => 'carousel',
                'value' => 'on'
            ),
            'edit_field_class' => 'vc_col-sm-4',
            'group' => esc_html__( 'Carousel', 'irepair' ),
        ),
    );

    vc_add_params( 'common_reviews', $carousel );
    vc_add_params( 'common_posts_block', $carousel );
    vc_add_params( 'common_brands', $carousel );
    vc_add_params( 'common_woocommerce', $carousel );

    function irepair_get_carousel($carousel_arr, $animation_func = ''){
        $options_arr = array();

        if( isset($carousel_arr['carousel']) && $carousel_arr['carousel'] == 'on' ) {
            unset($carousel_arr['carousel']);
            foreach ($carousel_arr as $key => $val) {
                $option = str_replace('carousel_', '', $key);
                if ($option == 'speed') {
                    $options_arr['navSpeed'] = $val;
                    $options_arr['dotsSpeed'] = $val;
                } elseif ($option == 'animation' && $val == 'on') {
                    $options_arr['onTranslate'] = $animation_func;
                } elseif ($option == 'margin') {
                    $options_arr[$option] = (int)$val;
                } elseif ($option == 'margin_tablet') {
                    $options_arr[$option] = (int)$val;
                } elseif ($option == 'margin_mobile') {
                    $options_arr[$option] = (int)$val;
                } elseif ($option == 'stagepadding') {
                    $options_arr['stagePadding'] = (int)$val;
                } elseif ($option == 'stagepadding_tablet') {
                    $options_arr['stagePadding_tablet'] = (int)$val;
                } elseif ($option == 'stagepadding_mobile') {
                    $options_arr['stagePadding_mobile'] = (int)$val;
                } elseif ( $val == 'on' || $val == 'off' ) {
                    $options_arr[$option] = $val == 'on' ? true : false;
                } else {
                    $options_arr[$option] = $val;
                }
            }
            $options_arr['responsiveClass'] = true;
            $options_arr['responsive'] = array(
                '0' => array(
                    'items' => 1,
                    'margin' => isset($options_arr['margin_mobile']) ? (int)$options_arr['margin_mobile'] : 0,
                    'stagePadding' => isset($options_arr['stagePadding_mobile']) ? (int)$options_arr['stagePadding_mobile'] : 0,
                ),
                '480' => array(
                    'items' => 2,
                    'margin' => isset($options_arr['margin_tablet']) ? (int)$options_arr['margin_tablet'] : 0,
                    'stagePadding' => isset($options_arr['stagePadding_tablet']) ? (int)$options_arr['stagePadding_tablet'] : 0,
                ),
                '768' => array(
                    'items' => isset($options_arr['items']) ? (int)$options_arr['items'] : 3,
                    'margin' => isset($options_arr['margin']) ? (int)$options_arr['margin'] : 0,
                    'stagePadding' => isset($options_arr['stagePadding']) ? (int)$options_arr['stagePadding'] : 0,
                )
            );
        }

        return $options_arr;
    }

?>