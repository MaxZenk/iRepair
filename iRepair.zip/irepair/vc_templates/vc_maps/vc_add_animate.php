<?php
	
	$add_animation = array(
		vc_map_add_css_animation(),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Duration", 'irepair' ),
			'param_name' => 'wow_duration',
			'value' => '',
			'description' => esc_html__( 'Change the animation duration in seconds.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Delay", 'irepair' ),
			'param_name' => 'wow_delay',
			'value' => '',
			'description' => esc_html__( 'Delay before the animation starts in seconds.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Offset", 'irepair' ),
			'param_name' => 'wow_offset',
			'value' => '',
			'description' => esc_html__( 'Distance to start the animation (related to the browser bottom) in pixels.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Iteration", 'irepair' ),
			'param_name' => 'wow_iteration',
			'value' => '',
			'description' => esc_html__( 'Number of times the animation is repeated.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
	);

	$add_animation_group = array(
		vc_map_add_css_animation(),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Items in Group", 'irepair' ),
			'param_name' => 'wow_group',
			'value' => '',
			'description' => esc_html__( 'Items number in animated group.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Group Delay Offset", 'irepair' ),
			'param_name' => 'wow_group_delay',
			'value' => '',
			'description' => esc_html__( 'Offset delay before the next group animation starts in seconds.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Duration", 'irepair' ),
			'param_name' => 'wow_duration',
			'value' => '',
			'description' => esc_html__( 'Change the animation duration in seconds.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Delay", 'irepair' ),
			'param_name' => 'wow_delay',
			'value' => '',
			'description' => esc_html__( 'Delay before the animation starts in seconds.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Offset", 'irepair' ),
			'param_name' => 'wow_offset',
			'value' => '',
			'description' => esc_html__( 'Distance to start the animation (related to the browser bottom) in pixels.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( "Iteration", 'irepair' ),
			'param_name' => 'wow_iteration',
			'value' => '',
			'description' => esc_html__( 'Number of times the animation is repeated.', 'irepair' ),
			'dependency' => array(
				'element' => 'css_animation',
				'not_empty' => true,
			),
		),
	);
?>