<?php
$out = '';

$out .= '
		<div class="subscribe">
			<div class="form-inline clearfix">
				'.do_shortcode('[mc4wp_form]').'
			</div>
		</div>	
	'; 

irepair_vc_widget_out($out);
