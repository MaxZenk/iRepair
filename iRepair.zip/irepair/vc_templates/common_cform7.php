<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $form_id
 * @var $css_animation
 * Shortcode class
 * @var $this WPBakeryShortCode_Block_Cform7
 */
$css_animation = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
$out = '';

$out = $css_animation != '' ? '<div class="animated" data-animation="' . esc_attr($css_animation) . '">' : '<div>';
$out .= do_shortcode('[contact-form-7 id="'.esc_attr($form_id).'"]');
$out .= '</div>';

irepair_vc_widget_out($out);